using System;
using System.IO;
using UnityEngine;

namespace HomeMerge.Save
{
    public class SaveService : MonoBehaviour
    {
        public static SaveService Instance { get; private set; }

        public const string CurrentSchemaVersion = "1.0.0";
        private const string SaveFileName = "homemerge_save.json";
        private const string BackupFileName = "homemerge_save.bak";

        private string _savePath;
        private string _backupPath;

        public event Action<GameStateData> OnGameSaved;
        public event Action<GameStateData> OnGameLoaded;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            _savePath = Path.Combine(Application.persistentDataPath, SaveFileName);
            _backupPath = Path.Combine(Application.persistentDataPath, BackupFileName);
        }

        public string GetSaveFilePath() => _savePath;

        public bool Save(GameStateData state)
        {
            if (state == null) return false;

            try
            {
                state.saveTimestampUtc = DateTime.UtcNow.ToString("o");
                state.schemaVersion = CurrentSchemaVersion;

                string json = JsonUtility.ToJson(state, true);
                string tempPath = _savePath + ".tmp";

                // Write to temporary file first (atomic safety)
                File.WriteAllText(tempPath, json);

                // Create backup of prior save if it exists
                if (File.Exists(_savePath))
                {
                    File.Copy(_savePath, _backupPath, true);
                }

                // Replace destination
                if (File.Exists(_savePath))
                {
                    File.Delete(_savePath);
                }
                File.Move(tempPath, _savePath);

                OnGameSaved?.Invoke(state);
                return true;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[SaveService] Failed to save game state: {ex.Message}");
                return false;
            }
        }

        public GameStateData Load()
        {
            // 1. Try primary save file
            if (File.Exists(_savePath))
            {
                try
                {
                    string json = File.ReadAllText(_savePath);
                    var data = JsonUtility.FromJson<GameStateData>(json);
                    if (ValidateLoadedData(data))
                    {
                        OnGameLoaded?.Invoke(data);
                        return data;
                    }
                    Debug.LogWarning("[SaveService] Primary save file validation failed, attempting backup recovery.");
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[SaveService] Primary save corrupted: {ex.Message}. Attempting backup recovery.");
                }
            }

            // 2. Try backup recovery file
            if (File.Exists(_backupPath))
            {
                try
                {
                    string backupJson = File.ReadAllText(_backupPath);
                    var backupData = JsonUtility.FromJson<GameStateData>(backupJson);
                    if (ValidateLoadedData(backupData))
                    {
                        Debug.Log("[SaveService] Successfully recovered game state from backup.");
                        OnGameLoaded?.Invoke(backupData);
                        return backupData;
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[SaveService] Backup recovery also failed: {ex.Message}");
                }
            }

            // 3. Fallback to clean default state
            Debug.Log("[SaveService] Initializing clean default state.");
            var defaultState = GameStateData.CreateDefault();
            Save(defaultState);
            OnGameLoaded?.Invoke(defaultState);
            return defaultState;
        }

        public bool ValidateLoadedData(GameStateData data)
        {
            if (data == null) return false;

            // Reject invalid schema version or missing fields
            if (string.IsNullOrEmpty(data.schemaVersion)) return false;

            // Reject impossible levels or negative currencies
            if (data.playerLevel < 1 || data.playerLevel > 999) return false;
            if (data.coins < 0 || data.stars < 0 || data.gems < 0 || data.playerXP < 0) return false;

            // Ensure lists are initialized
            if (data.boardItems == null) data.boardItems = new System.Collections.Generic.List<Items.ItemInstance>();
            if (data.activeOrders == null) data.activeOrders = new System.Collections.Generic.List<Orders.OrderData>();
            if (data.completedOrderIds == null) data.completedOrderIds = new System.Collections.Generic.List<string>();
            if (data.completedTaskIds == null) data.completedTaskIds = new System.Collections.Generic.List<string>();
            if (data.styleSelections == null) data.styleSelections = new System.Collections.Generic.List<StyleEntry>();
            if (data.settings == null) data.settings = new SettingsData();

            return true;
        }

        public void ResetSaveData()
        {
            try
            {
                if (File.Exists(_savePath)) File.Delete(_savePath);
                if (File.Exists(_backupPath)) File.Delete(_backupPath);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[SaveService] Could not delete old save files during reset: {ex.Message}");
            }

            var clean = GameStateData.CreateDefault();
            Save(clean);
            OnGameLoaded?.Invoke(clean);
        }
    }
}
