using System;
using HomeMerge.Board;
using HomeMerge.Core;
using HomeMerge.Orders;
using HomeMerge.Renovation;
using UnityEngine;
using UnityEngine.UI;

namespace HomeMerge.UI
{
    public class TutorialController : MonoBehaviour
    {
        public static TutorialController Instance { get; private set; }

        [Header("Tutorial Overlay")]
        [SerializeField] private GameObject tutorialContainer;
        [SerializeField] private Text messageText;
        [SerializeField] private Button nextOrActionButton;
        [SerializeField] private Button skipButton;

        public int CurrentStepIndex { get; private set; } = 0;
        public bool IsTutorialActive { get; private set; } = false;

        private readonly string[] _stepMessages = {
            "Welcome to Home Merge! This modest living room is completely run down. Let's restore it step-by-step!",
            "Tap the Tool Box Generator below to create basic home items for your board.",
            "Drag and drop matching Wood Scraps together to merge them into a Small Plank!",
            "Great job! Merging identical items levels them up into higher quality furniture and materials.",
            "Customer orders need these items! Notice Mrs. Higgins is asking for planks to fix her home.",
            "Tap 'Submit' on the order card to deliver the items and earn your first Coins and XP!",
            "Now let's invest your hard-earned Coins into renovating your living room. Tap 'Renovate'!",
            "Select Task #1: 'Clear the room' to remove the old debris and clutter.",
            "Look at that transformation! The room is clearing up and ready for new flooring and lighting.",
            "Congratulations! You've mastered the merge loop. Fulfill orders, renovate rooms, and design your dream house!"
        };

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        public void Initialize(bool isCompleted, int savedStep)
        {
            if (isCompleted)
            {
                IsTutorialActive = false;
                if (tutorialContainer != null) tutorialContainer.SetActive(false);
                return;
            }

            CurrentStepIndex = Mathf.Clamp(savedStep, 0, _stepMessages.Length - 1);
            IsTutorialActive = true;
            if (tutorialContainer != null) tutorialContainer.SetActive(true);

            if (skipButton != null)
            {
                skipButton.onClick.AddListener(SkipTutorial);
            }

            if (nextOrActionButton != null)
            {
                nextOrActionButton.onClick.AddListener(OnStepActionButtonClicked);
            }

            ShowCurrentStep();
        }

        public void ShowCurrentStep()
        {
            if (!IsTutorialActive || CurrentStepIndex >= _stepMessages.Length)
            {
                CompleteTutorial();
                return;
            }

            if (messageText != null)
            {
                messageText.text = _stepMessages[CurrentStepIndex];
            }
        }

        public void AdvanceStep(int expectedStep)
        {
            if (!IsTutorialActive) return;
            if (CurrentStepIndex == expectedStep)
            {
                CurrentStepIndex++;
                if (CurrentStepIndex >= _stepMessages.Length)
                {
                    CompleteTutorial();
                }
                else
                {
                    ShowCurrentStep();
                    if (GameBootstrap.Instance != null) GameBootstrap.Instance.TriggerSave();
                }
            }
        }

        private void OnStepActionButtonClicked()
        {
            // Dialog / explanation steps (0, 3, 8, 9) advance on button click
            if (CurrentStepIndex == 0 || CurrentStepIndex == 3 || CurrentStepIndex == 8 || CurrentStepIndex == 9)
            {
                AdvanceStep(CurrentStepIndex);
            }
        }

        public void SkipTutorial()
        {
            CompleteTutorial();
        }

        public void CompleteTutorial()
        {
            IsTutorialActive = false;
            CurrentStepIndex = _stepMessages.Length;
            if (tutorialContainer != null) tutorialContainer.SetActive(false);
            if (GameBootstrap.Instance != null) GameBootstrap.Instance.TriggerSave();
        }
    }
}
