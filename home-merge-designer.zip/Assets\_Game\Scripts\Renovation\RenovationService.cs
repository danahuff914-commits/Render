using System;
using System.Collections.Generic;
using HomeMerge.Economy;
using HomeMerge.Progression;
using UnityEngine;

namespace HomeMerge.Renovation
{
    public class RenovationService : MonoBehaviour
    {
        public static RenovationService Instance { get; private set; }

        private RoomData _currentRoom;
        private readonly HashSet<string> _completedTaskIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, string> _taskStyles = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

        public event Action<RenovationTaskData> OnTaskCompleted;
        public event Action<string, string> OnStyleSelected; // taskId, styleId
        public event Action OnRoomCompleted;

        public RoomData CurrentRoom => _currentRoom;
        public IReadOnlyCollection<string> CompletedTaskIds => _completedTaskIds;
        public IReadOnlyDictionary<string, string> TaskStyles => _taskStyles;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            InitializeDefaultRoom();
        }

        public void InitializeDefaultRoom()
        {
            _currentRoom = GenerateDefaultLivingRoom();
        }

        public void LoadRenovationState(List<string> completedIds, Dictionary<string, string> styles)
        {
            _completedTaskIds.Clear();
            _taskStyles.Clear();

            if (completedIds != null)
            {
                foreach (var id in completedIds) _completedTaskIds.Add(id);
            }

            if (styles != null)
            {
                foreach (var kvp in styles) _taskStyles[kvp.Key] = kvp.Value;
            }

            if (_currentRoom != null)
            {
                foreach (var task in _currentRoom.tasks)
                {
                    task.isCompleted = _completedTaskIds.Contains(task.taskId);
                    if (_taskStyles.TryGetValue(task.taskId, out string style))
                    {
                        task.selectedStyleId = style;
                    }
                }
            }
        }

        public RenovationTaskData GetNextAvailableTask()
        {
            if (_currentRoom == null) return null;
            foreach (var task in _currentRoom.tasks)
            {
                if (!_completedTaskIds.Contains(task.taskId))
                {
                    // Check prerequisite
                    if (string.IsNullOrEmpty(task.prerequisiteTaskId) || _completedTaskIds.Contains(task.prerequisiteTaskId))
                    {
                        return task;
                    }
                }
            }
            return null;
        }

        public bool CanExecuteTask(string taskId, EconomyService economy)
        {
            if (economy == null || _currentRoom == null) return false;
            var task = _currentRoom.tasks.Find(t => t.taskId == taskId);
            if (task == null || _completedTaskIds.Contains(taskId)) return false;

            // Prerequisite must be completed
            if (!string.IsNullOrEmpty(task.prerequisiteTaskId) && !_completedTaskIds.Contains(task.prerequisiteTaskId))
            {
                return false;
            }

            return economy.CanAfford(task.coinCost, task.starCost);
        }

        public bool TryExecuteTask(string taskId, string styleChoice, EconomyService economy, ProgressionService progression)
        {
            if (!CanExecuteTask(taskId, economy)) return false;

            var task = _currentRoom.tasks.Find(t => t.taskId == taskId);
            if (task == null) return false;

            // Atomic payment
            if (!economy.TrySpendBoth(task.coinCost, task.starCost))
            {
                return false;
            }

            // Apply state changes
            task.isCompleted = true;
            _completedTaskIds.Add(taskId);

            if (task.hasStyleSelection && !string.IsNullOrEmpty(styleChoice))
            {
                task.selectedStyleId = styleChoice;
                _taskStyles[taskId] = styleChoice;
                OnStyleSelected?.Invoke(taskId, styleChoice);
            }

            if (progression != null && task.xpReward > 0)
            {
                progression.AddXP(task.xpReward);
            }

            OnTaskCompleted?.Invoke(task);

            // Check if whole room completed (all 10 tasks)
            if (IsRoomFullyCompleted())
            {
                // Milestone bonus chest: 500 bonus coins + 20 gems!
                if (economy != null)
                {
                    economy.AddCoins(500);
                    economy.AddGems(20);
                }
                OnRoomCompleted?.Invoke();
            }

            return true;
        }

        public bool IsRoomFullyCompleted()
        {
            if (_currentRoom == null || _currentRoom.tasks.Count == 0) return false;
            foreach (var t in _currentRoom.tasks)
            {
                if (!_completedTaskIds.Contains(t.taskId)) return false;
            }
            return true;
        }

        public static RoomData GenerateDefaultLivingRoom()
        {
            var room = new RoomData
            {
                roomId = "living_room",
                roomTitle = "Modest Starter Living Room",
                description = "Transform an abandoned starter home into a stylish sanctuary.",
                requiredPlayerLevel = 1
            };

            var styleOptions = new List<RenovationStyleChoice>
            {
                new RenovationStyleChoice { styleId = "modern", displayName = "Modern", description = "Clean lines & muted tones." },
                new RenovationStyleChoice { styleId = "classic", displayName = "Classic", description = "Rich wood & timeless warmth." },
                new RenovationStyleChoice { styleId = "contemporary", displayName = "Contemporary", description = "Vibrant accents & bold patterns." }
            };

            room.tasks = new List<RenovationTaskData>
            {
                new RenovationTaskData
                {
                    taskId = "task_01",
                    taskIndex = 1,
                    title = "Clear the room",
                    description = "Remove trash and sweep out the old debris.",
                    coinCost = 50,
                    starCost = 0,
                    xpReward = 20,
                    prerequisiteTaskId = null,
                    hasStyleSelection = false
                },
                new RenovationTaskData
                {
                    taskId = "task_02",
                    taskIndex = 2,
                    title = "Repair the floor",
                    description = "Lay down durable, pristine hardwood flooring.",
                    coinCost = 80,
                    starCost = 0,
                    xpReward = 25,
                    prerequisiteTaskId = "task_01",
                    hasStyleSelection = true,
                    styleChoices = styleOptions
                },
                new RenovationTaskData
                {
                    taskId = "task_03",
                    taskIndex = 3,
                    title = "Paint the walls",
                    description = "Apply a fresh coat of premium designer paint.",
                    coinCost = 100,
                    starCost = 0,
                    xpReward = 30,
                    prerequisiteTaskId = "task_02",
                    hasStyleSelection = true,
                    styleChoices = styleOptions
                },
                new RenovationTaskData
                {
                    taskId = "task_04",
                    taskIndex = 4,
                    title = "Install a basic light",
                    description = "Bring warm ambient illumination into the living space.",
                    coinCost = 150,
                    starCost = 0,
                    xpReward = 35,
                    prerequisiteTaskId = "task_03",
                    hasStyleSelection = false
                },
                new RenovationTaskData
                {
                    taskId = "task_05",
                    taskIndex = 5,
                    title = "Add a rug",
                    description = "Place a plush area rug to center the seating area.",
                    coinCost = 180,
                    starCost = 1,
                    xpReward = 40,
                    prerequisiteTaskId = "task_04",
                    hasStyleSelection = true,
                    styleChoices = styleOptions
                },
                new RenovationTaskData
                {
                    taskId = "task_06",
                    taskIndex = 6,
                    title = "Place a side table",
                    description = "Set up a hand-crafted wooden table next to the seating area.",
                    coinCost = 200,
                    starCost = 0,
                    xpReward = 45,
                    prerequisiteTaskId = "task_05",
                    hasStyleSelection = false
                },
                new RenovationTaskData
                {
                    taskId = "task_07",
                    taskIndex = 7,
                    title = "Install the sofa",
                    description = "Position a comfortable designer sofa.",
                    coinCost = 250,
                    starCost = 1,
                    xpReward = 50,
                    prerequisiteTaskId = "task_06",
                    hasStyleSelection = true,
                    styleChoices = styleOptions
                },
                new RenovationTaskData
                {
                    taskId = "task_08",
                    taskIndex = 8,
                    title = "Add curtains",
                    description = "Hang tailored curtains to frame the natural window light.",
                    coinCost = 300,
                    starCost = 0,
                    xpReward = 55,
                    prerequisiteTaskId = "task_07",
                    hasStyleSelection = false
                },
                new RenovationTaskData
                {
                    taskId = "task_09",
                    taskIndex = 9,
                    title = "Add plants and wall décor",
                    description = "Bring life and personality with framed art and indoor plants.",
                    coinCost = 350,
                    starCost = 1,
                    xpReward = 60,
                    prerequisiteTaskId = "task_08",
                    hasStyleSelection = true,
                    styleChoices = styleOptions
                },
                new RenovationTaskData
                {
                    taskId = "task_10",
                    taskIndex = 10,
                    title = "Reveal the completed room",
                    description = "Celebrate the grand reveal of your dream living room!",
                    coinCost = 400,
                    starCost = 1,
                    xpReward = 100,
                    prerequisiteTaskId = "task_09",
                    hasStyleSelection = false
                }
            };

            return room;
        }
    }
}
