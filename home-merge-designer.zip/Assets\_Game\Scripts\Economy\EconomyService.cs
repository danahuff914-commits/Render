using System;
using UnityEngine;

namespace HomeMerge.Economy
{
    [Serializable]
    public class CurrencyWallet
    {
        public int coins = 100; // Starter coins
        public int stars = 0;
        public int gems = 10;
    }

    public class EconomyService : MonoBehaviour
    {
        public static EconomyService Instance { get; private set; }

        [SerializeField] private CurrencyWallet wallet = new CurrencyWallet();

        public event Action<int, int> OnCoinsChanged; // current, delta
        public event Action<int, int> OnStarsChanged; // current, delta
        public event Action<int, int> OnGemsChanged;  // current, delta

        public int Coins => wallet.coins;
        public int Stars => wallet.stars;
        public int Gems => wallet.gems;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        public void Initialize(int initialCoins, int initialStars, int initialGems)
        {
            wallet.coins = Mathf.Max(0, initialCoins);
            wallet.stars = Mathf.Max(0, initialStars);
            wallet.gems = Mathf.Max(0, initialGems);

            OnCoinsChanged?.Invoke(wallet.coins, 0);
            OnStarsChanged?.Invoke(wallet.stars, 0);
            OnGemsChanged?.Invoke(wallet.gems, 0);
        }

        public void AddCoins(int amount)
        {
            if (amount <= 0) return;
            wallet.coins += amount;
            OnCoinsChanged?.Invoke(wallet.coins, amount);
        }

        public bool TrySpendCoins(int amount)
        {
            if (amount < 0) return false;
            if (wallet.coins >= amount)
            {
                wallet.coins -= amount;
                OnCoinsChanged?.Invoke(wallet.coins, -amount);
                return true;
            }
            return false;
        }

        public void AddStars(int amount)
        {
            if (amount <= 0) return;
            wallet.stars += amount;
            OnStarsChanged?.Invoke(wallet.stars, amount);
        }

        public bool TrySpendStars(int amount)
        {
            if (amount < 0) return false;
            if (wallet.stars >= amount)
            {
                wallet.stars -= amount;
                OnStarsChanged?.Invoke(wallet.stars, -amount);
                return true;
            }
            return false;
        }

        public void AddGems(int amount)
        {
            if (amount <= 0) return;
            wallet.gems += amount;
            OnGemsChanged?.Invoke(wallet.gems, amount);
        }

        public bool TrySpendGems(int amount)
        {
            if (amount < 0) return false;
            if (wallet.gems >= amount)
            {
                wallet.gems -= amount;
                OnGemsChanged?.Invoke(wallet.gems, -amount);
                return true;
            }
            return false;
        }

        public bool CanAfford(int coinCost, int starCost = 0)
        {
            return wallet.coins >= coinCost && wallet.stars >= starCost;
        }

        public bool TrySpendBoth(int coinCost, int starCost)
        {
            if (wallet.coins >= coinCost && wallet.stars >= starCost)
            {
                wallet.coins -= coinCost;
                wallet.stars -= starCost;
                OnCoinsChanged?.Invoke(wallet.coins, -coinCost);
                OnStarsChanged?.Invoke(wallet.stars, -starCost);
                return true;
            }
            return false;
        }
    }
}
