using System;
using System.Collections.Generic;
using HomeMerge.Items;
using HomeMerge.Orders;

namespace HomeMerge.Save
{
    [Serializable]
    public class SettingsData
    {
        public bool sfxEnabled = true;
        public bool musicEnabled = true;
        public float sfxVolume = 1.0f;
        public float musicVolume = 0.7f;
        public bool reducedMotion = false;
    }

    [Serializable]
    public class StyleEntry
    {
        public string taskId;
        public string styleId;
    }

    [Serializable]
    public class GameStateData
    {
        public string schemaVersion = "1.0.0";
        public string saveTimestampUtc;

        // Player & Economy
        public int playerLevel = 1;
        public int playerXP = 0;
        public int coins = 100;
        public int stars = 0;
        public int gems = 10;

        // Board & Generator
        public List<ItemInstance> boardItems = new List<ItemInstance>();
        public int generatorCharges = 50;
        public bool energyEnabled = false;

        // Orders
        public List<OrderData> activeOrders = new List<OrderData>();
        public List<string> completedOrderIds = new List<string>();

        // Renovation & Rooms
        public string currentRoomId = "living_room";
        public List<string> completedTaskIds = new List<string>();
        public List<StyleEntry> styleSelections = new List<StyleEntry>();

        // Tutorial & Settings
        public bool tutorialCompleted = false;
        public int tutorialStep = 0;
        public SettingsData settings = new SettingsData();

        public static GameStateData CreateDefault()
        {
            var data = new GameStateData
            {
                schemaVersion = "1.0.0",
                saveTimestampUtc = DateTime.UtcNow.ToString("o"),
                playerLevel = 1,
                playerXP = 0,
                coins = 100,
                stars = 0,
                gems = 10,
                generatorCharges = 50,
                energyEnabled = false,
                tutorialCompleted = false,
                tutorialStep = 0,
                settings = new SettingsData()
            };

            // Starter board items for instant playability
            data.boardItems.Add(new ItemInstance("wood_01", 1, 1));
            data.boardItems.Add(new ItemInstance("wood_01", 2, 1));
            data.boardItems.Add(new ItemInstance("lighting_01", 3, 2));
            data.boardItems.Add(new ItemInstance("lighting_01", 4, 2));

            return data;
        }
    }
}
