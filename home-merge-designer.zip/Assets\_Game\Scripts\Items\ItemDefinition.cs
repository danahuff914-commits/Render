using System;
using UnityEngine;

namespace HomeMerge.Items
{
    [Serializable]
    [CreateAssetMenu(fileName = "ItemDefinition", menuMenu = "HomeMerge/ItemDefinition", order = 1)]
    public class ItemDefinition : ScriptableObject
    {
        public string id;
        public string familyId;
        public int level; // 1 to 8
        public string displayName;
        [TextArea(2, 4)]
        public string description;
        public int sellValue;
        public Sprite icon;
        public string[] tags;
        public int unlockRequirementLevel = 1;

        public bool CanMergeWith(ItemDefinition other)
        {
            if (other == null) return false;
            if (level >= 8) return false; // Max level cannot merge further
            return string.Equals(familyId, other.familyId, StringComparison.OrdinalIgnoreCase) &&
                   level == other.level;
        }
    }
}
