package com.homemergestudios.homemerge;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
