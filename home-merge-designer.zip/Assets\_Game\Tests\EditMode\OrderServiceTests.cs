using NUnit.Framework;
using HomeMerge.Board;
using HomeMerge.Economy;
using HomeMerge.Items;
using HomeMerge.Orders;
using HomeMerge.Progression;
using UnityEngine;

namespace HomeMerge.Tests
{
    [TestFixture]
    public class OrderServiceTests
    {
        private GameObject _go;
        private BoardController _board;
        private EconomyService _economy;
        private ProgressionService _progression;
        private OrderService _orderService;

        [SetUp]
        public void Setup()
        {
            _go = new GameObject("TestOrderSystem");
            var catalog = _go.AddComponent<ItemCatalog>();
            catalog.InitializeCatalog();

            _board = _go.AddComponent<BoardController>();
            _board.Initialize();

            _economy = _go.AddComponent<EconomyService>();
            _economy.Initialize(0, 0, 0);

            _progression = _go.AddComponent<ProgressionService>();
            _progression.Initialize(1, 0);

            _orderService = _go.AddComponent<OrderService>();
            _orderService.InitializeOrderPool();
            _orderService.RefillActiveOrders();
        }

        [TearDown]
        public void Teardown()
        {
            if (_go != null) Object.DestroyImmediate(_go);
        }

        [Test]
        public void IncompleteOrder_CannotBeSubmitted()
        {
            // Board is empty, order_001 requires 2x wood_02
            bool submitted = _orderService.TrySubmitOrder("order_001", _board, _economy, _progression);
            Assert.IsFalse(submitted);
            Assert.AreEqual(0, _economy.Coins);
        }

        [Test]
        public void ValidOrder_ConsumesRequiredItemsAndGrantsRewardsExactlyOnce()
        {
            // Place 2x wood_02 on board + 1 extra wood_01
            _board.SpawnItem("wood_02", out _);
            _board.SpawnItem("wood_02", out _);
            _board.SpawnItem("wood_01", out _);

            Assert.AreEqual(3, _board.Grid.GetAllItems().Count);

            bool submitted = _orderService.TrySubmitOrder("order_001", _board, _economy, _progression);
            Assert.IsTrue(submitted);

            // Exactly 2 wood_02 consumed, 1 wood_01 remaining
            Assert.AreEqual(1, _board.Grid.GetAllItems().Count);
            Assert.AreEqual("wood_01", _board.Grid.GetAllItems()[0].definitionId);

            // Order 001 reward is 50 coins and 10 XP
            Assert.AreEqual(50, _economy.Coins);
            Assert.AreEqual(10, _progression.CurrentXP);

            // Submitting again fails
            bool duplicateAttempt = _orderService.TrySubmitOrder("order_001", _board, _economy, _progression);
            Assert.IsFalse(duplicateAttempt);
            Assert.AreEqual(50, _economy.Coins);
        }
    }
}
