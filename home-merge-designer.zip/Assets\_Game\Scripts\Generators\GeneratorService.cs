using System;
using System.Collections.Generic;
using HomeMerge.Board;
using HomeMerge.Items;
using UnityEngine;

namespace HomeMerge.Generators
{
    [Serializable]
    public class GeneratorConfig
    {
        public bool energyEnabled = false;
        public int maxCharges = 50;
        public int currentCharges = 50;
        public float rechargeSeconds = 60f;
        public List<string> dropPoolDefIds = new List<string> { "wood_01", "lighting_01", "furniture_01" };
    }

    public class GeneratorService : MonoBehaviour
    {
        public static GeneratorService Instance { get; private set; }

        [SerializeField] private GeneratorConfig config = new GeneratorConfig();
        private float _timer = 0f;

        public event Action<int, int> OnChargesChanged; // current, max
        public event Action<ItemInstance> OnItemGenerated;
        public event Action OnBoardFull;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        private void Update()
        {
            if (config.energyEnabled && config.currentCharges < config.maxCharges)
            {
                _timer += Time.deltaTime;
                if (_timer >= config.rechargeSeconds)
                {
                    _timer = 0f;
                    config.currentCharges = Mathf.Min(config.maxCharges, config.currentCharges + 1);
                    OnChargesChanged?.Invoke(config.currentCharges, config.maxCharges);
                }
            }
        }

        public void LoadCharges(int charges, bool energyEnabled)
        {
            config.energyEnabled = energyEnabled;
            config.currentCharges = Mathf.Clamp(charges, 0, config.maxCharges);
            OnChargesChanged?.Invoke(config.currentCharges, config.maxCharges);
        }

        public int GetCurrentCharges() => config.currentCharges;
        public int GetMaxCharges() => config.maxCharges;
        public bool IsEnergyEnabled() => config.energyEnabled;

        public bool TryGenerateItem(out ItemInstance generated)
        {
            generated = null;

            if (config.energyEnabled && config.currentCharges <= 0)
            {
                return false;
            }

            var board = BoardController.Instance;
            if (board == null || board.Grid.IsBoardFull())
            {
                OnBoardFull?.Invoke();
                return false;
            }

            // Select random or weighted low-level item from pool
            string randomDefId = config.dropPoolDefIds[UnityEngine.Random.Range(0, config.dropPoolDefIds.Count)];

            if (board.SpawnItem(randomDefId, out generated))
            {
                if (config.energyEnabled)
                {
                    config.currentCharges--;
                    OnChargesChanged?.Invoke(config.currentCharges, config.maxCharges);
                }
                OnItemGenerated?.Invoke(generated);
                return true;
            }

            return false;
        }
    }
}
