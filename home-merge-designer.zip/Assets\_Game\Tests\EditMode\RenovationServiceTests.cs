using NUnit.Framework;
using HomeMerge.Economy;
using HomeMerge.Progression;
using HomeMerge.Renovation;
using UnityEngine;

namespace HomeMerge.Tests
{
    [TestFixture]
    public class RenovationServiceTests
    {
        private GameObject _go;
        private EconomyService _economy;
        private ProgressionService _progression;
        private RenovationService _renovation;

        [SetUp]
        public void Setup()
        {
            _go = new GameObject("TestRenovation");
            _economy = _go.AddComponent<EconomyService>();
            _economy.Initialize(100, 1, 0);

            _progression = _go.AddComponent<ProgressionService>();
            _progression.Initialize(1, 0);

            _renovation = _go.AddComponent<RenovationService>();
            _renovation.InitializeDefaultRoom();
        }

        [TearDown]
        public void Teardown()
        {
            if (_go != null) Object.DestroyImmediate(_go);
        }

        [Test]
        public void TaskRequiresPrerequisite_BlockedIfPrerequisiteNotComplete()
        {
            // Task 02 requires Task 01
            bool canExecute = _renovation.CanExecuteTask("task_02", _economy);
            Assert.IsFalse(canExecute);

            // Attempting execution fails atomically
            bool executed = _renovation.TryExecuteTask("task_02", "modern", _economy, _progression);
            Assert.IsFalse(executed);
            Assert.AreEqual(100, _economy.Coins);
        }

        [Test]
        public void TaskCompletion_DeductsCostAndAdvancesStateAtomically()
        {
            // Task 01: Clear room costs 50 coins
            bool executed = _renovation.TryExecuteTask("task_01", null, _economy, _progression);
            Assert.IsTrue(executed);
            Assert.AreEqual(50, _economy.Coins); // 100 - 50 = 50
            Assert.IsTrue(_renovation.CompletedTaskIds.Contains("task_01"));

            // Now Task 02 is unblocked
            var nextTask = _renovation.GetNextAvailableTask();
            Assert.IsNotNull(nextTask);
            Assert.AreEqual("task_02", nextTask.taskId);
        }

        [Test]
        public void StyleSelection_SavedAndRetained()
        {
            _renovation.TryExecuteTask("task_01", null, _economy, _progression);

            // Task 02 costs 80 coins, user has 50 coins -> cannot afford
            bool affordable = _renovation.CanExecuteTask("task_02", _economy);
            Assert.IsFalse(affordable);

            // Give player enough coins
            _economy.AddCoins(100); // 150 coins total
            bool executed = _renovation.TryExecuteTask("task_02", "contemporary", _economy, _progression);
            Assert.IsTrue(executed);

            Assert.AreEqual("contemporary", _renovation.TaskStyles["task_02"]);
        }
    }
}
