using System;
using System.Collections.Generic;
using HomeMerge.Items;
using UnityEngine;

namespace HomeMerge.Board
{
    [Serializable]
    public class BoardGrid
    {
        public const int Width = 8;
        public const int Height = 8;
        public const int TotalCells = Width * Height;

        // Flattened 8x8 grid: index = y * Width + x
        private readonly ItemInstance[] _cells = new ItemInstance[TotalCells];

        public ItemInstance GetItemAt(int x, int y)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return null;
            return _cells[y * Width + x];
        }

        public ItemInstance GetItemAt(int index)
        {
            if (index < 0 || index >= TotalCells) return null;
            return _cells[index];
        }

        public bool SetItemAt(int x, int y, ItemInstance item)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return false;
            int index = y * Width + x;
            _cells[index] = item;
            if (item != null)
            {
                item.gridX = x;
                item.gridY = y;
            }
            return true;
        }

        public void ClearCell(int x, int y)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return;
            _cells[y * Width + x] = null;
        }

        public bool IsCellEmpty(int x, int y)
        {
            if (x < 0 || x >= Width || y < 0 || y >= Height) return false;
            return _cells[y * Width + x] == null;
        }

        public bool IsBoardFull()
        {
            for (int i = 0; i < TotalCells; i++)
            {
                if (_cells[i] == null) return false;
            }
            return true;
        }

        public int EmptyCellCount()
        {
            int count = 0;
            for (int i = 0; i < TotalCells; i++)
            {
                if (_cells[i] == null) count++;
            }
            return count;
        }

        public bool FindFirstEmptyCell(out int outX, out int outY)
        {
            for (int y = 0; y < Height; y++)
            {
                for (int x = 0; x < Width; x++)
                {
                    if (_cells[y * Width + x] == null)
                    {
                        outX = x;
                        outY = y;
                        return true;
                    }
                }
            }
            outX = -1;
            outY = -1;
            return false;
        }

        public List<ItemInstance> GetAllItems()
        {
            var list = new List<ItemInstance>();
            for (int i = 0; i < TotalCells; i++)
            {
                if (_cells[i] != null) list.Add(_cells[i]);
            }
            return list;
        }

        public void ClearAll()
        {
            for (int i = 0; i < TotalCells; i++)
            {
                _cells[i] = null;
            }
        }
    }
}
