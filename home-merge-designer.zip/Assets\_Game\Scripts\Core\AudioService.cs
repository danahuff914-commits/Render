using System;
using UnityEngine;

namespace HomeMerge.Core
{
    public class AudioService : MonoBehaviour
    {
        public static AudioService Instance { get; private set; }

        [Header("Audio Sources")]
        [SerializeField] private AudioSource sfxSource;
        [SerializeField] private AudioSource musicSource;

        [Header("Audio Clips (Placeholders or Assigned)")]
        [SerializeField] private AudioClip tapClip;
        [SerializeField] private AudioClip mergeClip;
        [SerializeField] private AudioClip orderCompleteClip;
        [SerializeField] private AudioClip renovateClip;
        [SerializeField] private AudioClip buttonClickClip;
        [SerializeField] private AudioClip errorClip;
        [SerializeField] private AudioClip bgmMusicClip;

        public bool IsSfxMuted { get; private set; } = false;
        public bool IsMusicMuted { get; private set; } = false;
        public float SfxVolume { get; private set; } = 1.0f;
        public float MusicVolume { get; private set; } = 0.7f;

        public event Action<bool> OnSfxMuteChanged;
        public event Action<bool> OnMusicMuteChanged;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;

            if (sfxSource == null) sfxSource = gameObject.AddComponent<AudioSource>();
            if (musicSource == null)
            {
                musicSource = gameObject.AddComponent<AudioSource>();
                musicSource.loop = true;
            }
        }

        public void InitializeSettings(bool sfxMuted, bool musicMuted, float sfxVol, float musicVol)
        {
            IsSfxMuted = sfxMuted;
            IsMusicMuted = musicMuted;
            SfxVolume = Mathf.Clamp01(sfxVol);
            MusicVolume = Mathf.Clamp01(musicVol);

            ApplySettings();
        }

        public void SetSfxMuted(bool muted)
        {
            IsSfxMuted = muted;
            ApplySettings();
            OnSfxMuteChanged?.Invoke(muted);
        }

        public void SetMusicMuted(bool muted)
        {
            IsMusicMuted = muted;
            ApplySettings();
            OnMusicMuteChanged?.Invoke(muted);
        }

        public void SetSfxVolume(float volume)
        {
            SfxVolume = Mathf.Clamp01(volume);
            ApplySettings();
        }

        public void SetMusicVolume(float volume)
        {
            MusicVolume = Mathf.Clamp01(volume);
            ApplySettings();
        }

        private void ApplySettings()
        {
            if (sfxSource != null)
            {
                sfxSource.mute = IsSfxMuted;
                sfxSource.volume = SfxVolume;
            }
            if (musicSource != null)
            {
                musicSource.mute = IsMusicMuted;
                musicSource.volume = MusicVolume;
            }
        }

        public void PlayTap() => PlayClip(tapClip);
        public void PlayMerge() => PlayClip(mergeClip);
        public void PlayOrderComplete() => PlayClip(orderCompleteClip);
        public void PlayRenovate() => PlayClip(renovateClip);
        public void PlayButtonClick() => PlayClip(buttonClickClip);
        public void PlayError() => PlayClip(errorClip);

        private void PlayClip(AudioClip clip)
        {
            if (IsSfxMuted || sfxSource == null) return;
            if (clip != null)
            {
                sfxSource.PlayOneShot(clip, SfxVolume);
            }
        }

        public void PlayBGM()
        {
            if (musicSource == null || bgmMusicClip == null) return;
            if (musicSource.clip != bgmMusicClip)
            {
                musicSource.clip = bgmMusicClip;
            }
            if (!musicSource.isPlaying)
            {
                musicSource.Play();
            }
        }
    }
}
