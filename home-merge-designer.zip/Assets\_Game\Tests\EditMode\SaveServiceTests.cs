using NUnit.Framework;
using HomeMerge.Save;
using UnityEngine;

namespace HomeMerge.Tests
{
    [TestFixture]
    public class SaveServiceTests
    {
        private GameObject _go;
        private SaveService _saveService;

        [SetUp]
        public void Setup()
        {
            _go = new GameObject("TestSave");
            _saveService = _go.AddComponent<SaveService>();
        }

        [TearDown]
        public void Teardown()
        {
            if (_go != null) Object.DestroyImmediate(_go);
        }

        [Test]
        public void ValidData_PassesValidation()
        {
            var data = GameStateData.CreateDefault();
            bool isValid = _saveService.ValidateLoadedData(data);
            Assert.IsTrue(isValid);
        }

        [Test]
        public void CorruptedData_RejectedByValidation()
        {
            var badData = new GameStateData
            {
                coins = -50, // Negative balance forbidden
                playerLevel = 0 // Level must be >= 1
            };

            bool isValid = _saveService.ValidateLoadedData(badData);
            Assert.IsFalse(isValid);
        }

        [Test]
        public void MissingSchemaVersion_Rejected()
        {
            var badData = GameStateData.CreateDefault();
            badData.schemaVersion = null;

            bool isValid = _saveService.ValidateLoadedData(badData);
            Assert.IsFalse(isValid);
        }
    }
}
