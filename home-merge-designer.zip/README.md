# Home Merge: Dream House Designer

**Home Merge: Dream House Designer** is a casual merge-and-renovate mobile game built for portrait-first gameplay on Android, featuring an offline-first architecture, rich 8×8 merge board, data-driven item progression, customer order fulfillment, and living room interior redesign with stylistic personalization.

---

## 🎮 Play Instantly (Web Simulator)

You can launch and play the fully interactive game simulator immediately:

```bash
# Navigate to the project root
cd C:\Users\Priya\.gemini\antigravity\scratch\home-merge-designer

# Start the local development server
npm start
```
Then open your browser to: **[http://localhost:3000](http://localhost:3000)**

### Automated Tests:
```bash
npm test
```
Runs the 15-test automated acceptance suite covering all merge physics, orders, currencies, renovation tasks, and save states.

---

## 📱 Unity Project Overview

The project is structured according to the official GDD specification:
- **`Assets/_Game/Scripts/Core/`**: `GameBootstrap.cs`, `AudioService.cs`
- **`Assets/_Game/Scripts/Board/`**: `BoardController.cs`, `BoardGrid.cs`, `MergeService.cs`
- **`Assets/_Game/Scripts/Items/`**: `ItemDefinition.cs`, `ItemInstance.cs`, `ItemCatalog.cs`, `ItemFamily.cs`
- **`Assets/_Game/Scripts/Generators/`**: `GeneratorService.cs`
- **`Assets/_Game/Scripts/Orders/`**: `OrderData.cs`, `OrderService.cs`
- **`Assets/_Game/Scripts/Economy/`**: `EconomyService.cs`
- **`Assets/_Game/Scripts/Progression/`**: `ProgressionService.cs`
- **`Assets/_Game/Scripts/Renovation/`**: `RenovationTaskData.cs`, `RenovationService.cs`
- **`Assets/_Game/Scripts/Save/`**: `SaveService.cs`, `GameStateData.cs`
- **`Assets/_Game/Scripts/UI/`**: `MainUIController.cs`, `SettingsUIController.cs`, `TutorialController.cs`
- **`Assets/_Game/Tests/EditMode/`**: EditMode NUnit test suites (`MergeServiceTests.cs`, `EconomyServiceTests.cs`, `OrderServiceTests.cs`, `RenovationServiceTests.cs`, `SaveServiceTests.cs`)
- **`Documentation/`**: Complete system architecture, build guide, and test reports.

---

## 📋 Features Implemented in the MVP
1. **8×8 Merge Board**: Tactile drag-and-drop merging, valid drop highlight, invalid drop safety bounce, full-board warnings.
2. **3 Item Families (8 Levels Each = 24 Distinct Items)**:
   - Wood & Construction (Wood scrap ➔ Designer flooring set)
   - Lighting & Décor (Small bulb ➔ Signature lighting collection)
   - Furniture (Wooden stool ➔ Luxury lounge collection)
   *(Plus models for Fabrics, Tiles, and Plants ready for future expansion).*
3. **Generator System**: Tool box generator with charge limits and capacity protection.
4. **Customer Orders**: 8 data-driven sample orders with multi-item requirements, atomic item deduction, and coin/star/XP reward payouts.
5. **Living Room Renovation**: 10 progressive makeover tasks with style choices (*Modern*, *Classic*, *Contemporary*), visual room transformations, and grand completion bonus chest.
6. **Economy & Progression**: Coins, Stars, Gems, XP leveling system, non-negative balance safeguards.
7. **10-Step Interactive Tutorial**: Smooth onboarding guide explaining generation, merging, orders, and room restoration.
8. **Settings & Audio**: Real-time Web Audio synthesizer / Unity audio controller with independent SFX & Music toggles, and safe Reset Save confirmation.
9. **Offline-First Save System**: Versioned schema v1.0.0, atomic file updates, corrupted save validation, and safe defaults.

---

## 📖 Further Documentation
- [Architecture Deep Dive](file:///C:/Users/Priya/.gemini/antigravity/scratch/home-merge-designer/Documentation/ARCHITECTURE.md)
- [Setup & Android Build Guide](file:///C:/Users/Priya/.gemini/antigravity/scratch/home-merge-designer/Documentation/SETUP_AND_BUILD_GUIDE.md)
- [Test Report](file:///C:/Users/Priya/.gemini/antigravity/scratch/home-merge-designer/Documentation/TEST_REPORT.md)
