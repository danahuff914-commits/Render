using System;
using System.Collections.Generic;
using HomeMerge.Items;
using UnityEngine;

namespace HomeMerge.Board
{
    public class BoardController : MonoBehaviour
    {
        public static BoardController Instance { get; private set; }

        public BoardGrid Grid { get; private set; } = new BoardGrid();
        public MergeService MergeService { get; private set; }

        public event Action<ItemInstance, int, int> OnItemPlaced;
        public event Action<int, int> OnItemRemoved;
        public event Action<MergeResult> OnMergeCompleted;
        public event Action OnBoardStateChanged;
        public event Action OnBoardFullAttempt;

        private bool _isActionLocked = false;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            MergeService = new MergeService(ItemCatalog.Instance);
        }

        public void Initialize(List<ItemInstance> savedItems = null)
        {
            Grid.ClearAll();
            if (savedItems != null && savedItems.Count > 0)
            {
                foreach (var item in savedItems)
                {
                    if (item.gridX >= 0 && item.gridX < BoardGrid.Width &&
                        item.gridY >= 0 && item.gridY < BoardGrid.Height)
                    {
                        Grid.SetItemAt(item.gridX, item.gridY, item);
                    }
                }
            }
            OnBoardStateChanged?.Invoke();
        }

        public bool SpawnItem(string definitionId, out ItemInstance spawnedItem)
        {
            spawnedItem = null;
            if (Grid.IsBoardFull())
            {
                OnBoardFullAttempt?.Invoke();
                return false;
            }

            if (Grid.FindFirstEmptyCell(out int x, out int y))
            {
                spawnedItem = new ItemInstance(definitionId, x, y);
                Grid.SetItemAt(x, y, spawnedItem);
                OnItemPlaced?.Invoke(spawnedItem, x, y);
                OnBoardStateChanged?.Invoke();
                return true;
            }

            return false;
        }

        public bool TryMoveOrMerge(int fromX, int fromY, int toX, int toY, out bool wasMerged)
        {
            wasMerged = false;
            if (_isActionLocked) return false;

            if (fromX == toX && fromY == toY) return false;

            var source = Grid.GetItemAt(fromX, fromY);
            if (source == null) return false;

            var target = Grid.GetItemAt(toX, toY);

            // Empty target cell -> Move
            if (target == null)
            {
                Grid.ClearCell(fromX, fromY);
                Grid.SetItemAt(toX, toY, source);
                OnItemRemoved?.Invoke(fromX, fromY);
                OnItemPlaced?.Invoke(source, toX, toY);
                OnBoardStateChanged?.Invoke();
                return true;
            }

            // Target has an item -> Try Merge
            var validation = MergeService.ValidateMerge(source, target);
            if (validation == MergeValidationResult.Valid)
            {
                _isActionLocked = true;
                try
                {
                    // Remove source
                    Grid.ClearCell(fromX, fromY);
                    OnItemRemoved?.Invoke(fromX, fromY);

                    // Execute merge
                    var result = MergeService.ExecuteMerge(source, target);
                    wasMerged = true;

                    OnMergeCompleted?.Invoke(result);
                    OnItemPlaced?.Invoke(target, toX, toY);
                    OnBoardStateChanged?.Invoke();
                    return true;
                }
                finally
                {
                    _isActionLocked = false;
                }
            }

            // Invalid merge -> drop fails safely, item stays at original cell
            return false;
        }

        public bool RemoveItem(string instanceId)
        {
            for (int y = 0; y < BoardGrid.Height; y++)
            {
                for (int x = 0; x < BoardGrid.Width; x++)
                {
                    var item = Grid.GetItemAt(x, y);
                    if (item != null && item.instanceId == instanceId)
                    {
                        Grid.ClearCell(x, y);
                        OnItemRemoved?.Invoke(x, y);
                        OnBoardStateChanged?.Invoke();
                        return true;
                    }
                }
            }
            return false;
        }

        public List<ItemInstance> FindItemsByDefinition(string defId)
        {
            var results = new List<ItemInstance>();
            foreach (var item in Grid.GetAllItems())
            {
                if (string.Equals(item.definitionId, defId, StringComparison.OrdinalIgnoreCase))
                {
                    results.Add(item);
                }
            }
            return results;
        }
    }
}
