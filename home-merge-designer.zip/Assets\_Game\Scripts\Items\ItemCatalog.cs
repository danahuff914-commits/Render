using System;
using System.Collections.Generic;
using UnityEngine;

namespace HomeMerge.Items
{
    public class ItemCatalog : MonoBehaviour
    {
        public static ItemCatalog Instance { get; private set; }

        [SerializeField] private List<ItemDefinition> items = new List<ItemDefinition>();
        private readonly Dictionary<string, ItemDefinition> _byId = new Dictionary<string, ItemDefinition>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, Dictionary<int, ItemDefinition>> _byFamilyAndLevel = new Dictionary<string, Dictionary<int, ItemDefinition>>(StringComparer.OrdinalIgnoreCase);

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            InitializeCatalog();
        }

        public void InitializeCatalog()
        {
            _byId.Clear();
            _byFamilyAndLevel.Clear();

            // If empty (e.g. In test environment or default setup without manual SO assets), populate built-in defaults
            if (items == null || items.Count == 0)
            {
                items = GenerateDefaultCatalog();
            }

            foreach (var item in items)
            {
                if (item == null || string.IsNullOrEmpty(item.id)) continue;
                _byId[item.id] = item;

                if (!_byFamilyAndLevel.ContainsKey(item.familyId))
                {
                    _byFamilyAndLevel[item.familyId] = new Dictionary<int, ItemDefinition>();
                }
                _byFamilyAndLevel[item.familyId][item.level] = item;
            }
        }

        public ItemDefinition GetItem(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            if (_byId.Count == 0) InitializeCatalog();
            _byId.TryGetValue(id, out var def);
            return def;
        }

        public ItemDefinition GetItemByFamilyAndLevel(string familyId, int level)
        {
            if (string.IsNullOrEmpty(familyId)) return null;
            if (_byFamilyAndLevel.Count == 0) InitializeCatalog();

            if (_byFamilyAndLevel.TryGetValue(familyId, out var levels))
            {
                levels.TryGetValue(level, out var def);
                return def;
            }
            return null;
        }

        public ItemDefinition GetNextLevelItem(ItemDefinition current)
        {
            if (current == null || current.level >= 8) return null;
            return GetItemByFamilyAndLevel(current.familyId, current.level + 1);
        }

        public IReadOnlyList<ItemDefinition> GetAllItems()
        {
            if (_byId.Count == 0) InitializeCatalog();
            return items;
        }

        public static List<ItemDefinition> GenerateDefaultCatalog()
        {
            var list = new List<ItemDefinition>();

            // 1. Wood & Construction (Level 1 -> 8)
            string[] woodNames = {
                "Wood scrap", "Small plank", "Plank bundle", "Timber stack",
                "Finished wood panel", "Flooring sample", "Premium floor panel", "Designer flooring set"
            };
            for (int i = 0; i < woodNames.Length; i++)
            {
                var def = ScriptableObject.CreateInstance<ItemDefinition>();
                def.id = $"wood_{i + 1:D2}";
                def.familyId = "wood";
                def.level = i + 1;
                def.displayName = woodNames[i];
                def.description = $"Construction item level {i + 1}. Used for flooring and carpentry repairs.";
                def.sellValue = (i + 1) * 5;
                list.Add(def);
            }

            // 2. Lighting & Décor (Level 1 -> 8)
            string[] lightNames = {
                "Small bulb", "Simple lamp", "Table lamp", "Decorative lamp",
                "Designer floor lamp", "Pendant light", "Premium chandelier", "Signature lighting collection"
            };
            for (int i = 0; i < lightNames.Length; i++)
            {
                var def = ScriptableObject.CreateInstance<ItemDefinition>();
                def.id = $"lighting_{i + 1:D2}";
                def.familyId = "lighting";
                def.level = i + 1;
                def.displayName = lightNames[i];
                def.description = $"Lighting item level {i + 1}. Brightens the living room makeover.";
                def.sellValue = (i + 1) * 6;
                list.Add(def);
            }

            // 3. Furniture (Level 1 -> 8)
            string[] furnitureNames = {
                "Wooden stool", "Side table", "Accent chair", "Armchair",
                "Compact sofa", "Three-seat sofa", "Designer sofa set", "Luxury lounge collection"
            };
            for (int i = 0; i < furnitureNames.Length; i++)
            {
                var def = ScriptableObject.CreateInstance<ItemDefinition>();
                def.id = $"furniture_{i + 1:D2}";
                def.familyId = "furniture";
                def.level = i + 1;
                def.displayName = furnitureNames[i];
                def.description = $"Furniture item level {i + 1}. Key centerpiece for home living spaces.";
                def.sellValue = (i + 1) * 8;
                list.Add(def);
            }

            // Ready data model for Future Families:
            // 4. Fabrics & Curtains
            string[] fabricNames = {
                "Fabric scrap", "Fabric roll", "Fabric swatches", "Curtain fabric bundle",
                "Curtain panel", "Matched curtain pair", "Designer curtain set", "Luxury drapery collection"
            };
            for (int i = 0; i < fabricNames.Length; i++)
            {
                var def = ScriptableObject.CreateInstance<ItemDefinition>();
                def.id = $"fabrics_{i + 1:D2}";
                def.familyId = "fabrics";
                def.level = i + 1;
                def.displayName = fabricNames[i];
                def.description = $"Fabric item level {i + 1}.";
                def.sellValue = (i + 1) * 5;
                list.Add(def);
            }

            // 5. Tiles & Surfaces
            string[] tileNames = {
                "Tile fragment", "Single tile sample", "Tile sample pair", "Tile sample board",
                "Tile box", "Designer tile set", "Premium surface collection", "Signature tile collection"
            };
            for (int i = 0; i < tileNames.Length; i++)
            {
                var def = ScriptableObject.CreateInstance<ItemDefinition>();
                def.id = $"tiles_{i + 1:D2}";
                def.familyId = "tiles";
                def.level = i + 1;
                def.displayName = tileNames[i];
                def.description = $"Tile item level {i + 1}.";
                def.sellValue = (i + 1) * 5;
                list.Add(def);
            }

            // 6. Plants & Outdoor
            string[] plantNames = {
                "Seedling", "Small potted plant", "Decorative planter", "Plant pair",
                "Balcony arrangement", "Garden grouping", "Outdoor lounge accessory", "Premium garden collection"
            };
            for (int i = 0; i < plantNames.Length; i++)
            {
                var def = ScriptableObject.CreateInstance<ItemDefinition>();
                def.id = $"plants_{i + 1:D2}";
                def.familyId = "plants";
                def.level = i + 1;
                def.displayName = plantNames[i];
                def.description = $"Plant item level {i + 1}.";
                def.sellValue = (i + 1) * 5;
                list.Add(def);
            }

            return list;
        }
    }
}
