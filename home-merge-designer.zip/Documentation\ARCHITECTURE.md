# Home Merge: Dream House Designer — Technical Architecture

## 1. System Overview
Home Merge: Dream House Designer is an offline-first casual merge-and-renovate mobile game architected for portrait play on Android (and iOS). The game decouples presentation from simulation rules to ensure testability, data integrity, and atomic state updates.

```mermaid
flowchart TD
    GB[GameBootstrap] --> SS[SaveService]
    GB --> IC[ItemCatalog]
    GB --> ES[EconomyService]
    GB --> PS[ProgressionService]
    GB --> BC[BoardController]
    GB --> GS[GeneratorService]
    GB --> OS[OrderService]
    GB --> RS[RenovationService]
    GB --> AS[AudioService]
    GB --> UI[MainUIController]

    BC --> MS[MergeService]
    OS --> BC
    OS --> ES
    OS --> PS
    RS --> ES
    RS --> PS
```

---

## 2. Core Modules & Responsibilities

| Module | Location | Responsibility |
| :--- | :--- | :--- |
| **`GameBootstrap`** | `Assets/_Game/Scripts/Core/GameBootstrap.cs` | Bootstraps lifecycle, loads local save file, registers cross-service events, triggers auto-saves on state transitions. |
| **`BoardController`** | `Assets/_Game/Scripts/Board/BoardController.cs` | Manages 8×8 logical grid, cell slot placement, drag/drop coordination, bounds validation, and safe item removal. |
| **`BoardGrid`** | `Assets/_Game/Scripts/Board/BoardGrid.cs` | Flattened 64-element grid array, empty slot discovery, bounds checks, atomic placement and clearing. |
| **`MergeService`** | `Assets/_Game/Scripts/Board/MergeService.cs` | Enforces merge invariants: same family + same level -> level+1. Rejects mismatches and Level 8 items. |
| **`ItemCatalog`** | `Assets/_Game/Scripts/Items/ItemCatalog.cs` | Fast indexed repository of item definitions across 3 MVP families (24 items) and 3 future families. |
| **`GeneratorService`** | `Assets/_Game/Scripts/Generators/GeneratorService.cs` | Governs low-level item production, charge caps, optional recharge timers, and full-board safety locks. |
| **`OrderService`** | `Assets/_Game/Scripts/Orders/OrderService.cs` | Maintains active customer queue (up to 3 simultaneous orders), verifies requirements against board inventory, removes matching items atomically, and triggers rewards. |
| **`EconomyService`** | `Assets/_Game/Scripts/Economy/EconomyService.cs` | Manages wallet balances for Coins, Stars, and Gems. Enforces non-negative balances and transactional safety. |
| **`ProgressionService`** | `Assets/_Game/Scripts/Progression/ProgressionService.cs` | Tracks player XP and levels using progressive thresholds (`100 + (Lvl-1)*50`). Awards milestone bonuses. |
| **`RenovationService`** | `Assets/_Game/Scripts/Renovation/RenovationService.cs` | Enforces 10 living-room makeover tasks in sequence. Checks prerequisites and currency, handles style selections (Modern, Classic, Contemporary), and awards final chest. |
| **`SaveService`** | `Assets/_Game/Scripts/Save/SaveService.cs` | Atomic JSON file serialization (`.tmp` -> replace -> `.bak`), versioned schema (v1.0.0), schema validation, and corrupted file recovery. |
| **`AudioService`** | `Assets/_Game/Scripts/Core/AudioService.cs` | Low-latency audio cues for tap, merge, order completion, renovation reveal, and background music with independent mute/volume toggles. |
| **`TutorialController`**| `Assets/_Game/Scripts/UI/TutorialController.cs` | Guides new players through a 10-step first session loop. Skippable and persisted across sessions. |

---

## 3. Data Schema & Serialization

### Versioned Save Schema (`homemerge_save.json` v1.0.0)
```json
{
  "schemaVersion": "1.0.0",
  "saveTimestampUtc": "2026-10-26T10:45:00Z",
  "playerLevel": 1,
  "playerXP": 20,
  "coins": 150,
  "stars": 0,
  "gems": 10,
  "boardItems": [
    { "instanceId": "i_abc123", "definitionId": "wood_02", "gridX": 1, "gridY": 1 }
  ],
  "generatorCharges": 50,
  "energyEnabled": false,
  "activeOrders": [ ... ],
  "completedOrderIds": [ "order_001" ],
  "currentRoomId": "living_room",
  "completedTaskIds": [ "task_01" ],
  "styleSelections": [
    { "taskId": "task_02", "styleId": "contemporary" }
  ],
  "tutorialCompleted": true,
  "tutorialStep": 10,
  "settings": {
    "sfxEnabled": true,
    "musicEnabled": true,
    "sfxVolume": 1.0,
    "musicVolume": 0.7,
    "reducedMotion": false
  }
}
```

---

## 4. Item Families and Chains

### 1. Wood & Construction (`wood`)
- Level 1: Wood scrap
- Level 2: Small plank
- Level 3: Plank bundle
- Level 4: Timber stack
- Level 5: Finished wood panel
- Level 6: Flooring sample
- Level 7: Premium floor panel
- Level 8: Designer flooring set

### 2. Lighting & Décor (`lighting`)
- Level 1: Small bulb
- Level 2: Simple lamp
- Level 3: Table lamp
- Level 4: Decorative lamp
- Level 5: Designer floor lamp
- Level 6: Pendant light
- Level 7: Premium chandelier
- Level 8: Signature lighting collection

### 3. Furniture (`furniture`)
- Level 1: Wooden stool
- Level 2: Side table
- Level 3: Accent chair
- Level 4: Armchair
- Level 5: Compact sofa
- Level 6: Three-seat sofa
- Level 7: Designer sofa set
- Level 8: Luxury lounge collection

*(Models for Fabrics, Tiles, and Plants are registered in `ItemCatalog.cs` ready for Chapter 2 expansion).*
