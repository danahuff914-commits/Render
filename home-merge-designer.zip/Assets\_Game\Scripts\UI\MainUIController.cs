using UnityEngine;
using UnityEngine.UI;

namespace HomeMerge.UI
{
    public enum GameScreen
    {
        MergeBoard,
        RenovationRoom,
        ChapterMap,
        SettingsDialog
    }

    public class MainUIController : MonoBehaviour
    {
        public static MainUIController Instance { get; private set; }

        [Header("Screens")]
        [SerializeField] private GameObject mergeBoardScreen;
        [SerializeField] private GameObject renovationRoomScreen;
        [SerializeField] private GameObject chapterMapScreen;
        [SerializeField] private GameObject settingsDialog;

        [Header("Navigation Buttons")]
        [SerializeField] private Button toRenovationButton;
        [SerializeField] private Button toBoardButton;
        [SerializeField] private Button toChapterButton;
        [SerializeField] private Button toSettingsButton;
        [SerializeField] private Button closeSettingsButton;

        private GameScreen _currentScreen = GameScreen.MergeBoard;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;

            BindButtons();
        }

        private void Start()
        {
            ShowScreen(GameScreen.MergeBoard);
        }

        private void BindButtons()
        {
            if (toRenovationButton != null) toRenovationButton.onClick.AddListener(() => ShowScreen(GameScreen.RenovationRoom));
            if (toBoardButton != null) toBoardButton.onClick.AddListener(() => ShowScreen(GameScreen.MergeBoard));
            if (toChapterButton != null) toChapterButton.onClick.AddListener(() => ShowScreen(GameScreen.ChapterMap));
            if (toSettingsButton != null) toSettingsButton.onClick.AddListener(() => OpenSettings(true));
            if (closeSettingsButton != null) closeSettingsButton.onClick.AddListener(() => OpenSettings(false));
        }

        public void ShowScreen(GameScreen screen)
        {
            _currentScreen = screen;
            if (mergeBoardScreen != null) mergeBoardScreen.SetActive(screen == GameScreen.MergeBoard);
            if (renovationRoomScreen != null) renovationRoomScreen.SetActive(screen == GameScreen.RenovationRoom);
            if (chapterMapScreen != null) chapterMapScreen.SetActive(screen == GameScreen.ChapterMap);
        }

        public void OpenSettings(bool open)
        {
            if (settingsDialog != null) settingsDialog.SetActive(open);
        }
    }
}
