using NUnit.Framework;
using HomeMerge.Economy;
using UnityEngine;

namespace HomeMerge.Tests
{
    [TestFixture]
    public class EconomyServiceTests
    {
        private GameObject _go;
        private EconomyService _economy;

        [SetUp]
        public void Setup()
        {
            _go = new GameObject("TestEconomy");
            _economy = _go.AddComponent<EconomyService>();
            _economy.Initialize(100, 2, 10);
        }

        [TearDown]
        public void Teardown()
        {
            if (_go != null) Object.DestroyImmediate(_go);
        }

        [Test]
        public void InitialBalances_SetCorrectly()
        {
            Assert.AreEqual(100, _economy.Coins);
            Assert.AreEqual(2, _economy.Stars);
            Assert.AreEqual(10, _economy.Gems);
        }

        [Test]
        public void AddCoins_IncreasesBalance()
        {
            _economy.AddCoins(50);
            Assert.AreEqual(150, _economy.Coins);
        }

        [Test]
        public void TrySpendCoins_SucceedsWhenAffordable()
        {
            bool success = _economy.TrySpendCoins(40);
            Assert.IsTrue(success);
            Assert.AreEqual(60, _economy.Coins);
        }

        [Test]
        public void Currency_CannotGoNegative()
        {
            bool success = _economy.TrySpendCoins(200); // Has only 100
            Assert.IsFalse(success);
            Assert.AreEqual(100, _economy.Coins); // Balance untouched
        }

        [Test]
        public void TrySpendBoth_SucceedsOnlyWhenBothAreAvailable()
        {
            // Requires 80 coins and 1 star -> Affordable
            bool first = _economy.TrySpendBoth(80, 1);
            Assert.IsTrue(first);
            Assert.AreEqual(20, _economy.Coins);
            Assert.AreEqual(1, _economy.Stars);

            // Requires 50 coins and 1 star -> Insufficient coins (only 20 left)
            bool second = _economy.TrySpendBoth(50, 1);
            Assert.IsFalse(second);
            Assert.AreEqual(20, _economy.Coins); // Neither should be deducted
            Assert.AreEqual(1, _economy.Stars);
        }
    }
}
