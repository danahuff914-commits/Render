// Home Merge: Dream House Designer - Core Game Engine
// Modular Architecture mirroring Unity C# specification

// --- 1. Audio Synthesizer (Zero-dependency Web Audio API) ---
class AudioEngine {
    constructor() {
        this.ctx = null;
        this.sfxMuted = false;
        this.musicMuted = false;
        this.sfxVolume = 1.0;
        this.musicVolume = 0.5;
        this.bgmTimer = null;
    }

    init() {
        if (!this.ctx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                this.ctx = new AudioContext();
            }
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    playTone(freq, type, duration, startVol = 0.3) {
        if (this.sfxMuted || !this.ctx) return;
        try {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
            gain.gain.setValueAtTime(startVol * this.sfxVolume, this.ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start();
            osc.stop(this.ctx.currentTime + duration);
        } catch (e) { }
    }

    playTap() {
        this.init();
        this.playTone(480, 'sine', 0.08, 0.2);
    }

    playMerge() {
        this.init();
        if (this.sfxMuted || !this.ctx) return;
        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(320, now);
            osc.frequency.exponentialRampToValueAtTime(640, now + 0.15);
            gain.gain.setValueAtTime(0.35 * this.sfxVolume, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start();
            osc.stop(now + 0.2);
        } catch (e) { }
    }

    playOrderComplete() {
        this.init();
        if (this.sfxMuted || !this.ctx) return;
        const notes = [440, 554, 659, 880];
        notes.forEach((f, idx) => {
            setTimeout(() => this.playTone(f, 'sine', 0.2, 0.3), idx * 80);
        });
    }

    playRenovate() {
        this.init();
        if (this.sfxMuted || !this.ctx) return;
        const notes = [392, 523, 659, 784, 1046];
        notes.forEach((f, idx) => {
            setTimeout(() => this.playTone(f, 'triangle', 0.25, 0.25), idx * 70);
        });
    }

    playError() {
        this.init();
        this.playTone(180, 'sawtooth', 0.12, 0.25);
    }

    startBgm() {
        if (this.bgmTimer || this.musicMuted) return;
        // Subtle ambient chime loop every 8 seconds
        const playChime = () => {
            if (!this.musicMuted && this.ctx) {
                const freqs = [261.63, 329.63, 392.00, 523.25];
                freqs.forEach((f, i) => {
                    setTimeout(() => {
                        if (!this.musicMuted && this.ctx) {
                            try {
                                const osc = this.ctx.createOscillator();
                                const gain = this.ctx.createGain();
                                osc.type = 'sine';
                                osc.frequency.setValueAtTime(f, this.ctx.currentTime);
                                gain.gain.setValueAtTime(0.04 * this.musicVolume, this.ctx.currentTime);
                                gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 1.2);
                                osc.connect(gain);
                                gain.connect(this.ctx.destination);
                                osc.start();
                                osc.stop(this.ctx.currentTime + 1.2);
                            } catch (e) { }
                        }
                    }, i * 350);
                });
            }
        };
        this.bgmTimer = setInterval(playChime, 8000);
        playChime();
    }
}

// --- 2. Item Catalog & Progression Data ---
const ITEM_FAMILIES = {
    wood: {
        id: 'wood',
        name: 'Wood & Construction',
        icon: '🪵',
        color: '#c28549',
        items: [
            { level: 1, name: 'Wood scrap', icon: '🪵', desc: 'Raw scraps collected from old partitions.' },
            { level: 2, name: 'Small plank', icon: '📏', desc: 'Sanded small timber plank.' },
            { level: 3, name: 'Plank bundle', icon: '🪵', desc: 'Tied bundle of uniform timber.' },
            { level: 4, name: 'Timber stack', icon: '🪵', desc: 'Heavy seasoned lumber stack.' },
            { level: 5, name: 'Finished wood panel', icon: '🚪', desc: 'Sleek acoustic wall/floor panel.' },
            { level: 6, name: 'Flooring sample', icon: '🧱', desc: 'High-end hardwood floor sample.' },
            { level: 7, name: 'Premium floor panel', icon: '🏠', desc: 'Stained oak flooring panel.' },
            { level: 8, name: 'Designer flooring set', icon: '✨', desc: 'Mastercraft herringbone parquet set.' }
        ]
    },
    lighting: {
        id: 'lighting',
        name: 'Lighting & Décor',
        icon: '💡',
        color: '#e6a122',
        items: [
            { level: 1, name: 'Small bulb', icon: '💡', desc: 'Standard warm LED bulb.' },
            { level: 2, name: 'Simple lamp', icon: '🕯️', desc: 'Basic ambient desk light.' },
            { level: 3, name: 'Table lamp', icon: '🛋️', desc: 'Cozy ceramic bedside lamp.' },
            { level: 4, name: 'Decorative lamp', icon: '🏮', desc: 'Artisanal geometric lamp.' },
            { level: 5, name: 'Designer floor lamp', icon: '✨', desc: 'Architectural arched brass floor lamp.' },
            { level: 6, name: 'Pendant light', icon: '🔮', desc: 'Modern blown-glass pendant lamp.' },
            { level: 7, name: 'Premium chandelier', icon: '💎', desc: 'Crystal multi-tier chandelier.' },
            { level: 8, name: 'Signature lighting collection', icon: '🌟', desc: 'Museum-grade luminary masterpiece.' }
        ]
    },
    furniture: {
        id: 'furniture',
        name: 'Furniture',
        icon: '🪑',
        color: '#2a7b7a',
        items: [
            { level: 1, name: 'Wooden stool', icon: '🪵', desc: 'Sturdy rustic wooden perch.' },
            { level: 2, name: 'Side table', icon: '🪑', desc: 'Compact modern end table.' },
            { level: 3, name: 'Accent chair', icon: '🛋️', desc: 'Comfortable reading accent chair.' },
            { level: 4, name: 'Armchair', icon: '💺', desc: 'Plush mid-century modern armchair.' },
            { level: 5, name: 'Compact sofa', icon: '🛋️', desc: 'Two-seater tailored fabric loveseat.' },
            { level: 6, name: 'Three-seat sofa', icon: '🛋️', desc: 'Spacious ergonomic family sofa.' },
            { level: 7, name: 'Designer sofa set', icon: '🛋️', desc: 'Sectional modular lounge with ottomans.' },
            { level: 8, name: 'Luxury lounge collection', icon: '👑', desc: 'Italian velvet bespoke suite.' }
        ]
    }
};

// Flattened helper lookup
function getItemDef(defId) {
    if (!defId) return null;
    const parts = defId.split('_');
    const familyKey = parts[0];
    const level = parseInt(parts[1], 10);
    const family = ITEM_FAMILIES[familyKey];
    if (family && family.items[level - 1]) {
        return {
            id: defId,
            familyId: familyKey,
            level: level,
            displayName: family.items[level - 1].name,
            icon: family.items[level - 1].icon,
            description: family.items[level - 1].desc,
            color: family.color
        };
    }
    return null;
}

// --- 3. Board Grid Model (8x8) ---
class BoardGrid {
    constructor() {
        this.width = 8;
        this.height = 8;
        this.cells = new Array(64).fill(null);
    }

    index(x, y) {
        return y * this.width + x;
    }

    get(x, y) {
        if (x < 0 || x >= 8 || y < 0 || y >= 8) return null;
        return this.cells[this.index(x, y)];
    }

    set(x, y, item) {
        if (x < 0 || x >= 8 || y < 0 || y >= 8) return false;
        this.cells[this.index(x, y)] = item;
        if (item) {
            item.x = x;
            item.y = y;
        }
        return true;
    }

    clear(x, y) {
        if (x < 0 || x >= 8 || y < 0 || y >= 8) return;
        this.cells[this.index(x, y)] = null;
    }

    isFull() {
        return this.cells.every(c => c !== null);
    }

    findFirstEmpty() {
        for (let y = 0; y < 8; y++) {
            for (let x = 0; x < 8; x++) {
                if (this.cells[this.index(x, y)] === null) {
                    return { x, y };
                }
            }
        }
        return null;
    }

    getAllItems() {
        return this.cells.filter(c => c !== null);
    }
}

// --- 4. Renovation Tasks (10 MVP Tasks) ---
const RENOVATION_TASKS = [
    {
        id: 'task_01', index: 1, title: 'Clear the room',
        desc: 'Sweep out broken boards, dust, and spiderwebs.',
        coins: 50, stars: 0, xp: 20, prereq: null, hasStyle: false
    },
    {
        id: 'task_02', index: 2, title: 'Repair the floor',
        desc: 'Lay brand new pristine wood flooring.',
        coins: 80, stars: 0, xp: 25, prereq: 'task_01', hasStyle: true
    },
    {
        id: 'task_03', index: 3, title: 'Paint the walls',
        desc: 'Coat walls in an inviting, serene designer color.',
        coins: 100, stars: 0, xp: 30, prereq: 'task_02', hasStyle: true
    },
    {
        id: 'task_04', index: 4, title: 'Install a basic light',
        desc: 'Mount warm ambient ceiling lighting.',
        coins: 150, stars: 0, xp: 35, prereq: 'task_03', hasStyle: false
    },
    {
        id: 'task_05', index: 5, title: 'Add a rug',
        desc: 'Anchor the seating zone with an elegant area rug.',
        coins: 180, stars: 1, xp: 40, prereq: 'task_04', hasStyle: true
    },
    {
        id: 'task_06', index: 6, title: 'Place a side table',
        desc: 'Set up an artisan timber end table for lamps & drinks.',
        coins: 200, stars: 0, xp: 45, prereq: 'task_05', hasStyle: false
    },
    {
        id: 'task_07', index: 7, title: 'Install the sofa',
        desc: 'Add a luxurious, comfortable centerpiece sofa.',
        coins: 250, stars: 1, xp: 50, prereq: 'task_06', hasStyle: true
    },
    {
        id: 'task_08', index: 8, title: 'Add curtains',
        desc: 'Frame the windows with graceful drapery.',
        coins: 300, stars: 0, xp: 55, prereq: 'task_07', hasStyle: false
    },
    {
        id: 'task_09', index: 9, title: 'Add plants & wall décor',
        desc: 'Complete the ambiance with greenery and framed art.',
        coins: 350, stars: 1, xp: 60, prereq: 'task_08', hasStyle: true
    },
    {
        id: 'task_10', index: 10, title: 'Reveal completed room',
        desc: 'Celebrate the grand reveal and collect the bonus chest!',
        coins: 400, stars: 1, xp: 100, prereq: 'task_09', hasStyle: false
    }
];

// --- 5. Sample Orders Pool ---
const SAMPLE_ORDERS = [
    { id: 'order_001', customer: 'Mrs. Higgins', avatar: '👵', reqs: [{ defId: 'wood_02', count: 2 }], coins: 50, xp: 10, stars: 0 },
    { id: 'order_002', customer: 'David Carpenter', avatar: '👨‍🔧', reqs: [{ defId: 'lighting_03', count: 1 }], coins: 80, xp: 15, stars: 0 },
    { id: 'order_003', customer: 'Elena Vance', avatar: '👩‍🎨', reqs: [{ defId: 'furniture_02', count: 1 }], coins: 100, xp: 20, stars: 0 },
    { id: 'order_004', customer: 'Marcus Brody', avatar: '👨‍💼', reqs: [{ defId: 'wood_03', count: 1 }, { defId: 'lighting_02', count: 1 }], coins: 150, xp: 30, stars: 0 },
    { id: 'order_005', customer: 'Sophia Loren', avatar: '👩‍🦰', reqs: [{ defId: 'furniture_03', count: 1 }], coins: 180, xp: 35, stars: 0 },
    { id: 'order_006', customer: 'Architect Liam', avatar: '📐', reqs: [{ defId: 'wood_05', count: 1 }], coins: 220, xp: 40, stars: 0 },
    { id: 'order_007', customer: 'Grace Miller', avatar: '👩‍🏫', reqs: [{ defId: 'furniture_05', count: 1 }], coins: 300, xp: 55, stars: 0 },
    { id: 'order_008', customer: 'Mayor Higgins', avatar: '🎩', reqs: [{ defId: 'lighting_05', count: 1 }], coins: 400, xp: 75, stars: 1 }
];

// --- 6. Main Game Controller ---
class GameController {
    constructor() {
        this.audio = new AudioEngine();
        this.grid = new BoardGrid();
        this.level = 1;
        this.xp = 0;
        this.coins = 100;
        this.stars = 0;
        this.gems = 10;
        this.activeOrders = [];
        this.completedOrderIds = new Set();
        this.completedTaskIds = new Set();
        this.taskStyles = {};
        this.tutorialCompleted = false;
        this.tutorialStep = 0;
        this.reducedMotion = false;
        this.currentScreen = 'board'; // 'board', 'room', 'chapter'
        this.draggedItem = null;
        this.dragSourcePos = null;

        this.init();
    }

    init() {
        this.loadSave();
        this.renderAll();
        this.checkTutorial();
    }

    // Save & Load
    saveState() {
        const state = {
            schemaVersion: '1.0.0',
            timestamp: new Date().toISOString(),
            level: this.level,
            xp: this.xp,
            coins: this.coins,
            stars: this.stars,
            gems: this.gems,
            board: this.grid.getAllItems().map(item => ({
                id: item.id,
                defId: item.defId,
                x: item.x,
                y: item.y
            })),
            activeOrders: this.activeOrders,
            completedOrders: Array.from(this.completedOrderIds),
            completedTasks: Array.from(this.completedTaskIds),
            taskStyles: this.taskStyles,
            tutorialCompleted: this.tutorialCompleted,
            tutorialStep: this.tutorialStep,
            sfxMuted: this.audio.sfxMuted,
            musicMuted: this.audio.musicMuted,
            reducedMotion: this.reducedMotion
        };

        try {
            localStorage.setItem('homemerge_save_v1', JSON.stringify(state));
        } catch (e) {
            console.warn('LocalStorage save error:', e);
        }
    }

    loadSave() {
        let loaded = false;
        try {
            const raw = localStorage.getItem('homemerge_save_v1');
            if (raw) {
                const data = JSON.parse(raw);
                if (data && data.schemaVersion === '1.0.0' && data.coins >= 0 && data.level >= 1) {
                    this.level = data.level || 1;
                    this.xp = data.xp || 0;
                    this.coins = data.coins || 0;
                    this.stars = data.stars || 0;
                    this.gems = data.gems || 10;
                    this.completedOrderIds = new Set(data.completedOrders || []);
                    this.completedTaskIds = new Set(data.completedTasks || []);
                    this.taskStyles = data.taskStyles || {};
                    this.tutorialCompleted = data.tutorialCompleted || false;
                    this.tutorialStep = data.tutorialStep || 0;
                    this.audio.sfxMuted = !!data.sfxMuted;
                    this.audio.musicMuted = !!data.musicMuted;
                    this.reducedMotion = !!data.reducedMotion;

                    // Restore board
                    this.grid = new BoardGrid();
                    if (data.board && Array.isArray(data.board)) {
                        data.board.forEach(item => {
                            if (item.x >= 0 && item.x < 8 && item.y >= 0 && item.y < 8) {
                                this.grid.set(item.x, item.y, {
                                    id: item.id || ('i_' + Math.random().toString(36).substring(2, 9)),
                                    defId: item.defId,
                                    x: item.x,
                                    y: item.y
                                });
                            }
                        });
                    }

                    // Restore active orders
                    if (data.activeOrders && data.activeOrders.length > 0) {
                        this.activeOrders = data.activeOrders;
                    } else {
                        this.refillOrders();
                    }

                    loaded = true;
                }
            }
        } catch (e) {
            console.warn('Corrupted save loaded, starting safe default:', e);
        }

        if (!loaded) {
            this.initDefaultState();
        }
    }

    initDefaultState() {
        this.level = 1;
        this.xp = 0;
        this.coins = 100;
        this.stars = 0;
        this.gems = 10;
        this.completedOrderIds.clear();
        this.completedTaskIds.clear();
        this.taskStyles = {};
        this.tutorialCompleted = false;
        this.tutorialStep = 0;

        this.grid = new BoardGrid();
        // Starter items to immediately merge and experience the loop
        this.grid.set(1, 1, { id: 'item_start_1', defId: 'wood_01', x: 1, y: 1 });
        this.grid.set(2, 1, { id: 'item_start_2', defId: 'wood_01', x: 2, y: 1 });
        this.grid.set(3, 2, { id: 'item_start_3', defId: 'lighting_01', x: 3, y: 2 });
        this.grid.set(4, 2, { id: 'item_start_4', defId: 'lighting_01', x: 4, y: 2 });
        this.grid.set(1, 4, { id: 'item_start_5', defId: 'furniture_01', x: 1, y: 4 });

        this.refillOrders();
        this.saveState();
    }

    refillOrders() {
        while (this.activeOrders.length < 3) {
            let next = SAMPLE_ORDERS.find(o =>
                !this.completedOrderIds.has(o.id) &&
                !this.activeOrders.some(a => a.id === o.id)
            );
            if (!next) {
                // If exhausted, recycle with timestamp
                const base = SAMPLE_ORDERS[Math.floor(Math.random() * SAMPLE_ORDERS.length)];
                next = { ...base, id: `${base.id}_${Date.now().toString(36)}` };
            }
            this.activeOrders.push(JSON.parse(JSON.stringify(next)));
        }
    }

    // Generator logic
    tapGenerator() {
        this.audio.playTap();
        const emptyCell = this.grid.findFirstEmpty();
        if (!emptyCell) {
            this.showToast('Board is full! Merge items or complete orders.', 'warning');
            this.audio.playError();
            return false;
        }

        const pool = ['wood_01', 'wood_01', 'lighting_01', 'furniture_01'];
        const chosen = pool[Math.floor(Math.random() * pool.length)];
        const newItem = {
            id: 'item_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6),
            defId: chosen,
            x: emptyCell.x,
            y: emptyCell.y
        };

        this.grid.set(emptyCell.x, emptyCell.y, newItem);
        this.renderBoard();
        this.renderOrders();
        this.saveState();

        if (this.tutorialStep === 1) {
            this.advanceTutorial(2);
        }
        return true;
    }

    // Merge logic
    canMerge(itemA, itemB) {
        if (!itemA || !itemB || itemA.id === itemB.id) return false;
        const defA = getItemDef(itemA.defId);
        const defB = getItemDef(itemB.defId);
        if (!defA || !defB) return false;
        if (defA.level >= 8) return false;
        return defA.familyId === defB.familyId && defA.level === defB.level;
    }

    executeMerge(fromX, fromY, toX, toY) {
        const source = this.grid.get(fromX, fromY);
        const target = this.grid.get(toX, toY);

        if (!source || !target) return false;

        if (this.canMerge(source, target)) {
            const defTarget = getItemDef(target.defId);
            const nextDefId = `${defTarget.familyId}_${String(defTarget.level + 1).padStart(2, '0')}`;
            const nextDef = getItemDef(nextDefId);

            if (!nextDef) return false;

            // Atomically clear source & upgrade target
            this.grid.clear(fromX, fromY);
            target.defId = nextDefId;

            this.audio.playMerge();
            this.showToast(`Merged into ${nextDef.displayName}! ⭐`, 'success');

            this.renderBoard();
            this.renderOrders();
            this.saveState();

            if (this.tutorialStep === 2) {
                this.advanceTutorial(3);
            }
            return true;
        }
        return false;
    }

    moveItem(fromX, fromY, toX, toY) {
        if (fromX === toX && fromY === toY) return false;
        const source = this.grid.get(fromX, fromY);
        if (!source) return false;

        const target = this.grid.get(toX, toY);
        if (!target) {
            // Simple Move
            this.grid.clear(fromX, fromY);
            this.grid.set(toX, toY, source);
            this.renderBoard();
            this.saveState();
            return true;
        }

        // Try merge
        return this.executeMerge(fromX, fromY, toX, toY);
    }

    // Orders logic
    canFulfillOrder(order) {
        const counts = {};
        this.grid.getAllItems().forEach(item => {
            counts[item.defId] = (counts[item.defId] || 0) + 1;
        });

        return order.reqs.every(req => (counts[req.defId] || 0) >= req.count);
    }

    submitOrder(orderId) {
        const orderIdx = this.activeOrders.findIndex(o => o.id === orderId);
        if (orderIdx === -1) return false;
        const order = this.activeOrders[orderIdx];

        if (!this.canFulfillOrder(order)) {
            this.showToast('Missing required items for this order!', 'error');
            this.audio.playError();
            return false;
        }

        // Consume items atomically
        order.reqs.forEach(req => {
            let needed = req.count;
            for (let y = 0; y < 8; y++) {
                for (let x = 0; x < 8; x++) {
                    const item = this.grid.get(x, y);
                    if (item && item.defId === req.defId) {
                        this.grid.clear(x, y);
                        needed--;
                        if (needed <= 0) break;
                    }
                }
                if (needed <= 0) break;
            }
        });

        // Grant rewards
        this.coins += order.coins;
        if (order.stars) this.stars += order.stars;
        this.addXP(order.xp);

        this.completedOrderIds.add(order.id);
        this.activeOrders.splice(orderIdx, 1);
        this.refillOrders();

        this.audio.playOrderComplete();
        this.showToast(`Order Complete! +${order.coins} Coins, +${order.xp} XP`, 'reward');

        this.renderAll();
        this.saveState();

        if (this.tutorialStep === 5) {
            this.advanceTutorial(6);
        }
        return true;
    }

    addXP(amount) {
        this.xp += amount;
        let needed = 100 + (this.level - 1) * 50;
        while (this.xp >= needed) {
            this.xp -= needed;
            this.level++;
            this.coins += 50 * this.level;
            this.gems += 2;
            this.showToast(`Level Up! You reached Level ${this.level}! 🎉`, 'levelup');
            needed = 100 + (this.level - 1) * 50;
        }
    }

    // Renovation logic
    getNextTask() {
        return RENOVATION_TASKS.find(t => {
            if (this.completedTaskIds.has(t.id)) return false;
            return !t.prereq || this.completedTaskIds.has(t.prereq);
        });
    }

    canAffordTask(task) {
        if (!task) return false;
        return this.coins >= task.coins && this.stars >= (task.stars || 0);
    }

    executeRenovationTask(taskId, style = 'modern') {
        const task = RENOVATION_TASKS.find(t => t.id === taskId);
        if (!task || this.completedTaskIds.has(taskId)) return false;

        if (task.prereq && !this.completedTaskIds.has(task.prereq)) {
            this.showToast('Complete prior renovation tasks first!', 'warning');
            return false;
        }

        if (!this.canAffordTask(task)) {
            this.showToast(`Need ${task.coins} Coins & ${task.stars} Stars! Complete more orders.`, 'error');
            this.audio.playError();
            return false;
        }

        // Deduct
        this.coins -= task.coins;
        this.stars -= (task.stars || 0);
        this.addXP(task.xp);

        this.completedTaskIds.add(taskId);
        if (task.hasStyle) {
            this.taskStyles[taskId] = style;
        }

        this.audio.playRenovate();
        this.showToast(`Renovated: ${task.title}! 🏡`, 'success');

        if (this.completedTaskIds.size === RENOVATION_TASKS.length) {
            this.coins += 500;
            this.gems += 20;
            this.showToast('Room Complete! Awarded 500 Coins + 20 Gems Grand Bonus Chest! 🏆', 'reward');
        }

        this.renderAll();
        this.saveState();

        if (this.tutorialStep === 7) {
            this.advanceTutorial(8);
        }
        return true;
    }

    // Tutorial Flow
    checkTutorial() {
        if (this.tutorialCompleted) {
            document.getElementById('tutorial-modal').classList.add('hidden');
            return;
        }
        this.showTutorialStep(this.tutorialStep);
    }

    showTutorialStep(step) {
        const modal = document.getElementById('tutorial-modal');
        const text = document.getElementById('tutorial-text');
        const nextBtn = document.getElementById('tutorial-next-btn');

        const messages = [
            "Welcome to Home Merge! This modest living room is completely run down. Let's restore it step-by-step!",
            "Tap the Tool Box Generator at the bottom of the board to produce materials.",
            "Drag and drop two matching Wood Scraps together to merge them into a Small Plank!",
            "Great job! Merging identical items levels them up into higher quality furniture and materials.",
            "Customers in town need these materials! Notice Mrs. Higgins needs Small Planks.",
            "Tap 'Submit' on the order card to deliver your materials and earn Coins & XP!",
            "Now let's invest your hard-earned Coins into renovating your living room. Tap 'Renovate'!",
            "Tap 'Renovate (50 Coins)' on Task #1 to clear out the trash and rubble.",
            "Look at that transformation! The living room is clean and ready for flooring and lighting.",
            "Congratulations! You've mastered the merge loop. Keep merging, fulfill orders, and build your dream home!"
        ];

        if (step >= messages.length) {
            this.completeTutorial();
            return;
        }

        this.tutorialStep = step;
        text.innerText = messages[step];
        modal.classList.remove('hidden');

        // Only action-advance steps hide the next button
        if (step === 1 || step === 2 || step === 5 || step === 7) {
            nextBtn.classList.add('hidden');
        } else {
            nextBtn.classList.remove('hidden');
        }
        this.saveState();
    }

    advanceTutorial(expectedNext) {
        if (this.tutorialCompleted) return;
        this.showTutorialStep(expectedNext);
    }

    completeTutorial() {
        this.tutorialCompleted = true;
        document.getElementById('tutorial-modal').classList.add('hidden');
        this.saveState();
    }

    // Navigation
    switchScreen(screen) {
        this.currentScreen = screen;
        document.getElementById('screen-board').classList.toggle('hidden', screen !== 'board');
        document.getElementById('screen-room').classList.toggle('hidden', screen !== 'room');
        document.getElementById('screen-chapter').classList.toggle('hidden', screen !== 'chapter');

        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.screen === screen);
        });

        if (screen === 'room') {
            this.renderRoom();
            if (this.tutorialStep === 6) {
                this.advanceTutorial(7);
            }
        }
    }

    // UI Rendering
    renderAll() {
        this.renderTopBar();
        this.renderBoard();
        this.renderOrders();
        this.renderRoom();
    }

    renderTopBar() {
        document.getElementById('player-level-badge').innerText = `Lvl ${this.level}`;
        const neededXP = 100 + (this.level - 1) * 50;
        const xpPct = Math.min(100, (this.xp / neededXP) * 100);
        document.getElementById('xp-bar-fill').style.width = `${xpPct}%`;
        document.getElementById('xp-text').innerText = `${this.xp}/${neededXP} XP`;
        document.getElementById('coin-balance').innerText = this.coins;
        document.getElementById('star-balance').innerText = this.stars;
        document.getElementById('gem-balance').innerText = this.gems;

        const nextTask = this.getNextTask();
        const canAfford = nextTask && this.canAffordTask(nextTask);
        const badge = document.getElementById('renovate-alert-badge');
        if (badge) badge.classList.toggle('hidden', !canAfford);
    }

    renderBoard() {
        const boardEl = document.getElementById('merge-grid');
        boardEl.innerHTML = '';

        for (let y = 0; y < 8; y++) {
            for (let x = 0; x < 8; x++) {
                const cell = document.createElement('div');
                cell.className = 'grid-cell';
                cell.dataset.x = x;
                cell.dataset.y = y;

                const item = this.grid.get(x, y);
                if (item) {
                    const def = getItemDef(item.defId);
                    if (def) {
                        const tile = document.createElement('div');
                        tile.className = 'item-tile';
                        tile.draggable = true;
                        tile.dataset.id = item.id;
                        tile.dataset.x = x;
                        tile.dataset.y = y;
                        tile.style.setProperty('--family-color', def.color);

                        tile.innerHTML = `
                            <div class="item-icon">${def.icon}</div>
                            <div class="item-level-tag">L${def.level}</div>
                            <div class="item-name">${def.displayName}</div>
                        `;

                        // Drag & Drop Handlers
                        tile.addEventListener('dragstart', (e) => {
                            this.draggedItem = item;
                            this.dragSourcePos = { x, y };
                            e.dataTransfer.setData('text/plain', item.id);
                            tile.classList.add('dragging');
                        });

                        tile.addEventListener('dragend', () => {
                            tile.classList.remove('dragging');
                            document.querySelectorAll('.grid-cell').forEach(c => c.classList.remove('drag-over', 'valid-target'));
                        });

                        cell.appendChild(tile);
                    }
                }

                // Cell drop listeners
                cell.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    if (this.draggedItem) {
                        cell.classList.add('drag-over');
                        const targetItem = this.grid.get(x, y);
                        if (targetItem && this.canMerge(this.draggedItem, targetItem)) {
                            cell.classList.add('valid-target');
                        }
                    }
                });

                cell.addEventListener('dragleave', () => {
                    cell.classList.remove('drag-over', 'valid-target');
                });

                cell.addEventListener('drop', (e) => {
                    e.preventDefault();
                    cell.classList.remove('drag-over', 'valid-target');
                    if (this.dragSourcePos) {
                        this.moveItem(this.dragSourcePos.x, this.dragSourcePos.y, x, y);
                        this.dragSourcePos = null;
                        this.draggedItem = null;
                    }
                });

                boardEl.appendChild(cell);
            }
        }
    }

    renderOrders() {
        const orderContainer = document.getElementById('orders-container');
        orderContainer.innerHTML = '';

        this.activeOrders.forEach(order => {
            const card = document.createElement('div');
            card.className = 'order-card';

            const canSubmit = this.canFulfillOrder(order);
            if (canSubmit) card.classList.add('ready');

            let reqsHtml = order.reqs.map(req => {
                const def = getItemDef(req.defId);
                const hasCount = this.grid.getAllItems().filter(i => i.defId === req.defId).length;
                const isMet = hasCount >= req.count;
                return `
                    <div class="order-req-pill ${isMet ? 'met' : 'unmet'}">
                        <span>${def ? def.icon : '📦'} ${def ? def.displayName : req.defId}</span>
                        <strong>${hasCount}/${req.count}</strong>
                    </div>
                `;
            }).join('');

            card.innerHTML = `
                <div class="order-header">
                    <span class="customer-avatar">${order.avatar || '👤'}</span>
                    <span class="customer-name">${order.customer}</span>
                </div>
                <div class="order-reqs">${reqsHtml}</div>
                <div class="order-footer">
                    <div class="order-rewards">
                        <span>🪙 +${order.coins}</span>
                        <span>⭐ +${order.xp} XP</span>
                        ${order.stars ? `<span>🌟 +${order.stars}</span>` : ''}
                    </div>
                    <button class="order-submit-btn ${canSubmit ? 'enabled' : 'disabled'}" ${canSubmit ? '' : 'disabled'}>
                        Deliver
                    </button>
                </div>
            `;

            card.querySelector('.order-submit-btn').addEventListener('click', () => {
                this.submitOrder(order.id);
            });

            orderContainer.appendChild(card);
        });
    }

    renderRoom() {
        const nextTask = this.getNextTask();
        const taskBanner = document.getElementById('room-task-banner');
        const roomView = document.getElementById('room-view-canvas');

        // Apply completed task classes to visually render the room transformation
        RENOVATION_TASKS.forEach(t => {
            const isDone = this.completedTaskIds.has(t.id);
            roomView.classList.toggle(`task-done-${t.id}`, isDone);
            if (t.hasStyle && this.taskStyles[t.id]) {
                roomView.dataset[`style_${t.id}`] = this.taskStyles[t.id];
            }
        });

        // Calculate progress percentage
        const pct = Math.round((this.completedTaskIds.size / RENOVATION_TASKS.length) * 100);
        document.getElementById('room-progress-text').innerText = `${this.completedTaskIds.size}/${RENOVATION_TASKS.length} Tasks (${pct}%)`;
        document.getElementById('room-progress-fill').style.width = `${pct}%`;

        if (nextTask) {
            const canAfford = this.canAffordTask(nextTask);
            taskBanner.innerHTML = `
                <div class="task-info">
                    <div class="task-step">Task #${nextTask.index}</div>
                    <div class="task-title">${nextTask.title}</div>
                    <div class="task-desc">${nextTask.desc}</div>
                </div>
                <div class="task-action-box">
                    <button id="task-renovate-btn" class="renovate-btn ${canAfford ? 'affordable' : 'unaffordable'}">
                        Renovate (🪙 ${nextTask.coins}${nextTask.stars ? ` + 🌟 ${nextTask.stars}` : ''})
                    </button>
                </div>
            `;

            document.getElementById('task-renovate-btn').addEventListener('click', () => {
                if (nextTask.hasStyle) {
                    this.openStyleModal(nextTask);
                } else {
                    this.executeRenovationTask(nextTask.id);
                }
            });
        } else {
            taskBanner.innerHTML = `
                <div class="room-completed-banner">
                    <h3>🏆 Living Room Masterpiece Completed!</h3>
                    <p>All 10 makeover tasks are done. Enjoy your stunning dream space!</p>
                </div>
            `;
        }
    }

    openStyleModal(task) {
        const modal = document.getElementById('style-picker-modal');
        document.getElementById('style-modal-title').innerText = `Choose Style: ${task.title}`;

        const optionsContainer = document.getElementById('style-options-container');
        optionsContainer.innerHTML = '';

        const styles = [
            { id: 'modern', name: 'Modern Minimalism', desc: 'Clean lines, airy neutrals & sleek wood.' },
            { id: 'classic', name: 'Timeless Classic', desc: 'Warm mahogany, rich textures & heritage grace.' },
            { id: 'contemporary', name: 'Contemporary Chic', desc: 'Vibrant accents, playful geometry & cozy warmth.' }
        ];

        styles.forEach(s => {
            const opt = document.createElement('div');
            opt.className = 'style-card';
            opt.innerHTML = `
                <div class="style-name">${s.name}</div>
                <div class="style-desc">${s.desc}</div>
                <button class="select-style-btn">Select & Renovate</button>
            `;
            opt.querySelector('.select-style-btn').addEventListener('click', () => {
                modal.classList.add('hidden');
                this.executeRenovationTask(task.id, s.id);
            });
            optionsContainer.appendChild(opt);
        });

        modal.classList.remove('hidden');
    }

    showToast(msg, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerText = msg;
        container.appendChild(toast);
        setTimeout(() => {
            toast.classList.add('fade-out');
            setTimeout(() => toast.remove(), 400);
        }, 2200);
    }
}

// Global initialization
window.addEventListener('DOMContentLoaded', () => {
    window.game = new GameController();

    // Bottom Navigation
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            window.game.switchScreen(btn.dataset.screen);
        });
    });

    // Generator Tap Button
    document.getElementById('generator-tap-btn').addEventListener('click', () => {
        window.game.tapGenerator();
    });

    // Tutorial Next Button
    document.getElementById('tutorial-next-btn').addEventListener('click', () => {
        window.game.advanceTutorial(window.game.tutorialStep + 1);
    });

    // Tutorial Skip Button
    document.getElementById('tutorial-skip-btn').addEventListener('click', () => {
        window.game.completeTutorial();
    });

    // Settings Modal
    const settingsModal = document.getElementById('settings-modal');
    document.getElementById('settings-btn').addEventListener('click', () => {
        settingsModal.classList.remove('hidden');
    });
    document.getElementById('settings-close-btn').addEventListener('click', () => {
        settingsModal.classList.add('hidden');
    });

    // Sound Toggles
    const sfxToggle = document.getElementById('sfx-toggle');
    const musicToggle = document.getElementById('music-toggle');
    sfxToggle.checked = !window.game.audio.sfxMuted;
    musicToggle.checked = !window.game.audio.musicMuted;

    sfxToggle.addEventListener('change', (e) => {
        window.game.audio.sfxMuted = !e.target.checked;
        window.game.saveState();
    });
    musicToggle.addEventListener('change', (e) => {
        window.game.audio.musicMuted = !e.target.checked;
        if (!window.game.audio.musicMuted) window.game.audio.startBgm();
        window.game.saveState();
    });

    // Reset Save Confirmation
    const resetModal = document.getElementById('reset-confirm-modal');
    document.getElementById('reset-save-btn').addEventListener('click', () => {
        resetModal.classList.remove('hidden');
    });
    document.getElementById('reset-no-btn').addEventListener('click', () => {
        resetModal.classList.add('hidden');
    });
    document.getElementById('reset-yes-btn').addEventListener('click', () => {
        localStorage.removeItem('homemerge_save_v1');
        resetModal.classList.add('hidden');
        settingsModal.classList.add('hidden');
        window.game.initDefaultState();
        window.game.renderAll();
        window.game.showToast('Game progress reset to default.', 'warning');
    });

    // Style modal close
    document.getElementById('style-modal-close-btn').addEventListener('click', () => {
        document.getElementById('style-picker-modal').classList.add('hidden');
    });

    // First user gesture starts WebAudio
    document.body.addEventListener('click', () => {
        window.game.audio.init();
        window.game.audio.startBgm();
    }, { once: true });
});
