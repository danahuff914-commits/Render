using System;
using System.Collections.Generic;

namespace HomeMerge.Orders
{
    public enum OrderType
    {
        Simple,
        Combined,
        Advanced,
        Chapter
    }

    [Serializable]
    public class OrderRequirement
    {
        public string definitionId;
        public int count = 1;

        public OrderRequirement() { }

        public OrderRequirement(string defId, int qty)
        {
            definitionId = defId;
            count = qty;
        }
    }

    [Serializable]
    public class OrderData
    {
        public string orderId;
        public string customerName;
        public string customerAvatar;
        public OrderType orderType;
        public List<OrderRequirement> requirements = new List<OrderRequirement>();
        public int coinReward;
        public int xpReward;
        public int starReward;
        public bool isCompleted;

        public OrderData Clone()
        {
            var clone = new OrderData
            {
                orderId = this.orderId,
                customerName = this.customerName,
                customerAvatar = this.customerAvatar,
                orderType = this.orderType,
                coinReward = this.coinReward,
                xpReward = this.xpReward,
                starReward = this.starReward,
                isCompleted = this.isCompleted,
                requirements = new List<OrderRequirement>()
            };
            foreach (var req in this.requirements)
            {
                clone.requirements.Add(new OrderRequirement(req.definitionId, req.count));
            }
            return clone;
        }
    }
}
