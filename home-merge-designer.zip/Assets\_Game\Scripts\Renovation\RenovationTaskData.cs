using System;
using System.Collections.Generic;

namespace HomeMerge.Renovation
{
    [Serializable]
    public class RenovationStyleChoice
    {
        public string styleId;
        public string displayName;
        public string description;
        public string assetKey;
    }

    [Serializable]
    public class RenovationTaskData
    {
        public string taskId;
        public int taskIndex; // 1 to 10
        public string title;
        public string description;
        public int coinCost;
        public int starCost;
        public int xpReward;
        public string prerequisiteTaskId;
        public bool hasStyleSelection;
        public List<RenovationStyleChoice> styleChoices = new List<RenovationStyleChoice>();
        public string selectedStyleId = "modern";
        public bool isCompleted;
    }

    [Serializable]
    public class RoomData
    {
        public string roomId = "living_room";
        public string roomTitle = "Modest Starter Living Room";
        public string description = "Transform an abandoned starter home into a stylish sanctuary.";
        public int requiredPlayerLevel = 1;
        public List<RenovationTaskData> tasks = new List<RenovationTaskData>();
    }
}
