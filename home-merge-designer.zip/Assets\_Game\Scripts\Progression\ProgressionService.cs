using System;
using HomeMerge.Economy;
using UnityEngine;

namespace HomeMerge.Progression
{
    public class ProgressionService : MonoBehaviour
    {
        public static ProgressionService Instance { get; private set; }

        public int CurrentLevel { get; private set; } = 1;
        public int CurrentXP { get; private set; } = 0;

        public event Action<int, int> OnXPChanged; // currentXP, xpForNextLevel
        public event Action<int> OnLevelUp;        // newLevel

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        public void Initialize(int level, int xp)
        {
            CurrentLevel = Mathf.Max(1, level);
            CurrentXP = Mathf.Max(0, xp);
            OnXPChanged?.Invoke(CurrentXP, GetXPRequiredForLevel(CurrentLevel));
        }

        public int GetXPRequiredForLevel(int level)
        {
            // Pacing formula: base 100 XP per level + 50 per level above 1
            return 100 + (level - 1) * 50;
        }

        public void AddXP(int amount)
        {
            if (amount <= 0) return;
            CurrentXP += amount;

            int needed = GetXPRequiredForLevel(CurrentLevel);
            while (CurrentXP >= needed)
            {
                CurrentXP -= needed;
                CurrentLevel++;
                OnLevelUp?.Invoke(CurrentLevel);

                // Milestone reward on level up: bonus coins and gems
                if (EconomyService.Instance != null)
                {
                    EconomyService.Instance.AddCoins(50 * CurrentLevel);
                    EconomyService.Instance.AddGems(2);
                }

                needed = GetXPRequiredForLevel(CurrentLevel);
            }

            OnXPChanged?.Invoke(CurrentXP, needed);
        }
    }
}
