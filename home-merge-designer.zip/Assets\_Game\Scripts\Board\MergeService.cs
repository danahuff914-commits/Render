using System;
using HomeMerge.Items;
using UnityEngine;

namespace HomeMerge.Board
{
    public enum MergeValidationResult
    {
        Valid,
        SameCell,
        EmptyTarget,
        FamilyMismatch,
        LevelMismatch,
        MaxLevelReached,
        InvalidSource
    }

    public class MergeResult
    {
        public bool Success;
        public MergeValidationResult ValidationResult;
        public ItemInstance SourceItem;
        public ItemInstance UpgradedItem;
        public ItemDefinition NewDefinition;
    }

    public class MergeService
    {
        private readonly ItemCatalog _catalog;

        public event Action<MergeResult> OnMergeExecuted;

        public MergeService(ItemCatalog catalog)
        {
            _catalog = catalog ?? ItemCatalog.Instance;
        }

        public MergeValidationResult ValidateMerge(ItemInstance source, ItemInstance target)
        {
            if (source == null) return MergeValidationResult.InvalidSource;
            if (target == null) return MergeValidationResult.EmptyTarget;
            if (source.instanceId == target.instanceId) return MergeValidationResult.SameCell;

            var sourceDef = _catalog.GetItem(source.definitionId);
            var targetDef = _catalog.GetItem(target.definitionId);

            if (sourceDef == null || targetDef == null)
                return MergeValidationResult.InvalidSource;

            if (!string.Equals(sourceDef.familyId, targetDef.familyId, StringComparison.OrdinalIgnoreCase))
                return MergeValidationResult.FamilyMismatch;

            if (sourceDef.level != targetDef.level)
                return MergeValidationResult.LevelMismatch;

            if (sourceDef.level >= 8)
                return MergeValidationResult.MaxLevelReached;

            return MergeValidationResult.Valid;
        }

        public MergeResult ExecuteMerge(ItemInstance source, ItemInstance target)
        {
            var validation = ValidateMerge(source, target);
            if (validation != MergeValidationResult.Valid)
            {
                return new MergeResult
                {
                    Success = false,
                    ValidationResult = validation,
                    SourceItem = source,
                    UpgradedItem = target,
                    NewDefinition = null
                };
            }

            var currentDef = _catalog.GetItem(target.definitionId);
            var nextDef = _catalog.GetNextLevelItem(currentDef);

            if (nextDef == null)
            {
                return new MergeResult
                {
                    Success = false,
                    ValidationResult = MergeValidationResult.MaxLevelReached,
                    SourceItem = source,
                    UpgradedItem = target
                };
            }

            // Atomic mutation: target definition updated to next level
            target.definitionId = nextDef.id;

            var result = new MergeResult
            {
                Success = true,
                ValidationResult = MergeValidationResult.Valid,
                SourceItem = source,
                UpgradedItem = target,
                NewDefinition = nextDef
            };

            OnMergeExecuted?.Invoke(result);
            return result;
        }
    }
}
