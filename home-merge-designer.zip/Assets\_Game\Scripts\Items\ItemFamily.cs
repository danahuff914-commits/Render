using System;

namespace HomeMerge.Items
{
    [Serializable]
    public enum ItemFamilyType
    {
        Wood = 0,
        Lighting = 1,
        Furniture = 2,
        Fabrics = 3,
        Tiles = 4,
        Plants = 5
    }

    [Serializable]
    public class ItemFamilyInfo
    {
        public ItemFamilyType FamilyType;
        public string FamilyId;
        public string DisplayName;
        public string Description;
        public bool IsMvpActive;
    }
}
