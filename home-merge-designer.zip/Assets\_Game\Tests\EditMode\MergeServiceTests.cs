using NUnit.Framework;
using HomeMerge.Board;
using HomeMerge.Items;
using UnityEngine;

namespace HomeMerge.Tests
{
    [TestFixture]
    public class MergeServiceTests
    {
        private ItemCatalog _catalog;
        private MergeService _mergeService;

        [SetUp]
        public void Setup()
        {
            var go = new GameObject("TestCatalog");
            _catalog = go.AddComponent<ItemCatalog>();
            _catalog.InitializeCatalog();
            _mergeService = new MergeService(_catalog);
        }

        [TearDown]
        public void Teardown()
        {
            if (_catalog != null)
            {
                Object.DestroyImmediate(_catalog.gameObject);
            }
        }

        [Test]
        public void SameFamilyAndLevel_MergesSuccessfullyToNextLevel()
        {
            var source = new ItemInstance("wood_01", 0, 0); // Wood scrap (Lvl 1)
            var target = new ItemInstance("wood_01", 0, 1); // Wood scrap (Lvl 1)

            var validation = _mergeService.ValidateMerge(source, target);
            Assert.AreEqual(MergeValidationResult.Valid, validation);

            var result = _mergeService.ExecuteMerge(source, target);
            Assert.IsTrue(result.Success);
            Assert.AreEqual("wood_02", target.definitionId); // Small plank (Lvl 2)
            Assert.AreEqual(2, result.NewDefinition.level);
        }

        [Test]
        public void DifferentFamily_RejectsMerge()
        {
            var wood = new ItemInstance("wood_01", 0, 0);
            var lamp = new ItemInstance("lighting_01", 0, 1);

            var validation = _mergeService.ValidateMerge(wood, lamp);
            Assert.AreEqual(MergeValidationResult.FamilyMismatch, validation);

            var result = _mergeService.ExecuteMerge(wood, lamp);
            Assert.IsFalse(result.Success);
            Assert.AreEqual("lighting_01", lamp.definitionId); // Target untouched
        }

        [Test]
        public void DifferentLevel_RejectsMerge()
        {
            var lvl1 = new ItemInstance("wood_01", 0, 0);
            var lvl2 = new ItemInstance("wood_02", 0, 1);

            var validation = _mergeService.ValidateMerge(lvl1, lvl2);
            Assert.AreEqual(MergeValidationResult.LevelMismatch, validation);

            var result = _mergeService.ExecuteMerge(lvl1, lvl2);
            Assert.IsFalse(result.Success);
        }

        [Test]
        public void MaxLevel_CannotMergeFurther()
        {
            var max1 = new ItemInstance("wood_08", 0, 0); // Designer flooring set (Lvl 8)
            var max2 = new ItemInstance("wood_08", 0, 1);

            var validation = _mergeService.ValidateMerge(max1, max2);
            Assert.AreEqual(MergeValidationResult.MaxLevelReached, validation);

            var result = _mergeService.ExecuteMerge(max1, max2);
            Assert.IsFalse(result.Success);
        }

        [Test]
        public void SameItem_CannotMergeWithItself()
        {
            var item = new ItemInstance("wood_01", 0, 0);
            var validation = _mergeService.ValidateMerge(item, item);
            Assert.AreEqual(MergeValidationResult.SameCell, validation);
        }
    }
}
