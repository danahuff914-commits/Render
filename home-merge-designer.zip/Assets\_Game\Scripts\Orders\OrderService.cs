using System;
using System.Collections.Generic;
using HomeMerge.Board;
using HomeMerge.Economy;
using HomeMerge.Items;
using HomeMerge.Progression;
using UnityEngine;

namespace HomeMerge.Orders
{
    public class OrderService : MonoBehaviour
    {
        public static OrderService Instance { get; private set; }

        public const int MaxActiveOrders = 3;

        private readonly List<OrderData> _activeOrders = new List<OrderData>();
        private readonly HashSet<string> _completedOrderIds = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private List<OrderData> _orderPool = new List<OrderData>();

        public event Action<OrderData> OnOrderCompleted;
        public event Action OnOrdersChanged;

        public IReadOnlyList<OrderData> ActiveOrders => _activeOrders;
        public IReadOnlyCollection<string> CompletedOrderIds => _completedOrderIds;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            InitializeOrderPool();
        }

        public void InitializeOrderPool()
        {
            _orderPool = GenerateDefaultOrders();
        }

        public void LoadOrders(List<OrderData> active, List<string> completed)
        {
            _activeOrders.Clear();
            _completedOrderIds.Clear();

            if (completed != null)
            {
                foreach (var id in completed) _completedOrderIds.Add(id);
            }

            if (active != null && active.Count > 0)
            {
                foreach (var o in active) _activeOrders.Add(o);
            }
            else
            {
                RefillActiveOrders();
            }

            OnOrdersChanged?.Invoke();
        }

        public void RefillActiveOrders()
        {
            if (_orderPool == null || _orderPool.Count == 0) InitializeOrderPool();

            while (_activeOrders.Count < MaxActiveOrders)
            {
                OrderData nextOrder = null;
                foreach (var order in _orderPool)
                {
                    if (!_completedOrderIds.Contains(order.orderId) &&
                        !_activeOrders.Exists(o => o.orderId == order.orderId))
                    {
                        nextOrder = order.Clone();
                        break;
                    }
                }

                // If all completed, recycle starting orders with slight variation to prevent progression dead ends
                if (nextOrder == null)
                {
                    var baseOrder = _orderPool[UnityEngine.Random.Range(0, _orderPool.Count)];
                    nextOrder = baseOrder.Clone();
                    nextOrder.orderId = $"{baseOrder.orderId}_{Guid.NewGuid().ToString("N").Substring(0, 4)}";
                }

                _activeOrders.Add(nextOrder);
            }

            OnOrdersChanged?.Invoke();
        }

        public bool CanFulfillOrder(OrderData order, BoardController board)
        {
            if (order == null || board == null) return false;

            // Count available items on board by definition ID
            var availableCounts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var item in board.Grid.GetAllItems())
            {
                if (!availableCounts.ContainsKey(item.definitionId))
                    availableCounts[item.definitionId] = 0;
                availableCounts[item.definitionId]++;
            }

            foreach (var req in order.requirements)
            {
                if (!availableCounts.TryGetValue(req.definitionId, out int count) || count < req.count)
                {
                    return false;
                }
            }

            return true;
        }

        public bool TrySubmitOrder(string orderId, BoardController board, EconomyService economy, ProgressionService progression)
        {
            var order = _activeOrders.Find(o => o.orderId == orderId);
            if (order == null || order.isCompleted) return false;

            if (!CanFulfillOrder(order, board)) return false;

            // Atomically collect item instances to remove
            var itemsToRemove = new List<ItemInstance>();
            foreach (var req in order.requirements)
            {
                var matching = board.FindItemsByDefinition(req.definitionId);
                int needed = req.count;
                foreach (var item in matching)
                {
                    if (!itemsToRemove.Contains(item))
                    {
                        itemsToRemove.Add(item);
                        needed--;
                        if (needed <= 0) break;
                    }
                }
                if (needed > 0) return false; // Safety check
            }

            // Remove items atomically
            foreach (var item in itemsToRemove)
            {
                board.RemoveItem(item.instanceId);
            }

            // Mark order completed and record history
            order.isCompleted = true;
            _completedOrderIds.Add(order.orderId);
            _activeOrders.Remove(order);

            // Grant rewards once
            if (economy != null)
            {
                economy.AddCoins(order.coinReward);
                if (order.starReward > 0)
                {
                    economy.AddStars(order.starReward);
                }
            }
            if (progression != null && order.xpReward > 0)
            {
                progression.AddXP(order.xpReward);
            }

            OnOrderCompleted?.Invoke(order);

            // Refill to keep active queue full
            RefillActiveOrders();
            return true;
        }

        public static List<OrderData> GenerateDefaultOrders()
        {
            return new List<OrderData>
            {
                // Order 001: Two small planks -> 50 coins + 10 XP
                new OrderData
                {
                    orderId = "order_001",
                    customerName = "Mrs. Higgins",
                    orderType = OrderType.Simple,
                    requirements = new List<OrderRequirement> { new OrderRequirement("wood_02", 2) },
                    coinReward = 50,
                    xpReward = 10,
                    starReward = 0
                },
                // Order 002: One table lamp -> 80 coins + 15 XP
                new OrderData
                {
                    orderId = "order_002",
                    customerName = "David Carpenter",
                    orderType = OrderType.Simple,
                    requirements = new List<OrderRequirement> { new OrderRequirement("lighting_03", 1) },
                    coinReward = 80,
                    xpReward = 15,
                    starReward = 0
                },
                // Order 003: One side table -> 100 coins + 20 XP
                new OrderData
                {
                    orderId = "order_003",
                    customerName = "Elena Vance",
                    orderType = OrderType.Simple,
                    requirements = new List<OrderRequirement> { new OrderRequirement("furniture_02", 1) },
                    coinReward = 100,
                    xpReward = 20,
                    starReward = 0
                },
                // Order 004: One plank bundle + one simple lamp -> 150 coins + 30 XP
                new OrderData
                {
                    orderId = "order_004",
                    customerName = "Marcus Brody",
                    orderType = OrderType.Combined,
                    requirements = new List<OrderRequirement>
                    {
                        new OrderRequirement("wood_03", 1),
                        new OrderRequirement("lighting_02", 1)
                    },
                    coinReward = 150,
                    xpReward = 30,
                    starReward = 0
                },
                // Order 005: One accent chair -> 180 coins + 35 XP
                new OrderData
                {
                    orderId = "order_005",
                    customerName = "Sophia Loren",
                    orderType = OrderType.Advanced,
                    requirements = new List<OrderRequirement> { new OrderRequirement("furniture_03", 1) },
                    coinReward = 180,
                    xpReward = 35,
                    starReward = 0
                },
                // Order 006: One finished wood panel -> 220 coins + 40 XP
                new OrderData
                {
                    orderId = "order_006",
                    customerName = "Architect Liam",
                    orderType = OrderType.Advanced,
                    requirements = new List<OrderRequirement> { new OrderRequirement("wood_05", 1) },
                    coinReward = 220,
                    xpReward = 40,
                    starReward = 0
                },
                // Order 007: One compact sofa -> 300 coins + 55 XP
                new OrderData
                {
                    orderId = "order_007",
                    customerName = "Grace Miller",
                    orderType = OrderType.Advanced,
                    requirements = new List<OrderRequirement> { new OrderRequirement("furniture_05", 1) },
                    coinReward = 300,
                    xpReward = 55,
                    starReward = 0
                },
                // Order 008: One designer floor lamp + star reward -> 400 coins + 75 XP + 1 star
                new OrderData
                {
                    orderId = "order_008",
                    customerName = "Mayor Higgins",
                    orderType = OrderType.Chapter,
                    requirements = new List<OrderRequirement> { new OrderRequirement("lighting_05", 1) },
                    coinReward = 400,
                    xpReward = 75,
                    starReward = 1
                }
            };
        }
    }
}
