# Home Merge: Dream House Designer — Setup & Build Guide

## 1. Quick Verification: Instant Web Simulator & Test Runner
The project includes an immediately playable standalone browser simulator and headless automated test suite located in `playable_build/`.

### Run Automated Acceptance Tests:
```powershell
cd C:\Users\Priya\.gemini\antigravity\scratch\home-merge-designer
npm test
# OR
node playable_build/test_runner.js
```
*Executes all 15 critical acceptance tests covering merge logic, order consumption, currency integrity, atomic renovation, and save/load serialization.*

### Launch Playable Web Build:
```powershell
cd C:\Users\Priya\.gemini\antigravity\scratch\home-merge-designer
npm start
# OR
node playable_build/server.js
```
Open **`http://localhost:3000`** in any desktop or mobile browser.
- **Experience the complete core loop:**
  1. Complete the 10-step guided first-session tutorial.
  2. Tap the Tool Box generator to spawn Wood Scraps, Bulbs, and Stools.
  3. Drag and drop matching items to merge up through 8 item levels.
  4. Fulfill orders for Mrs. Higgins, David Carpenter, etc., to collect Coins & XP.
  5. Open the "Renovate" tab and progress through the 10 Living Room tasks.
  6. Choose décor styles (*Modern*, *Classic*, *Contemporary*) at milestone tasks.
  7. Test settings, audio synthesis, and the reset-save confirmation dialog.
  8. Close and reopen the tab to verify progress persistence in versioned LocalStorage.

---

## 2. Opening & Running the Unity Project

### Prerequisites:
- **Unity 2022.3 LTS** (or Unity 6000.0+ LTS)
- **Unity Hub**
- **Android Build Support** (with OpenJDK and Android SDK & NDK tools installed via Unity Hub)

### Steps:
1. Open **Unity Hub**.
2. Click **Add** -> **Add project from disk**.
3. Select the folder:  
   `C:\Users\Priya\.gemini\antigravity\scratch\home-merge-designer`
4. Select Unity Editor version **2022.3.x LTS** and open the project.
5. In the Project window, navigate to:  
   `Assets/_Game/Scenes/MainGame.unity` (or create a new Scene and attach `GameBootstrap.cs` to an empty GameObject named `[GameBootstrap]`).
6. Press the **Play** button in the Unity Editor toolbar.

---

## 3. Running Unity Tests
1. In the Unity Editor top menu, select:  
   **Window** > **General** > **Test Runner**.
2. Under the **EditMode** tab, click **Run All**.
3. The following test suites will execute:
   - `MergeServiceTests` (5 tests)
   - `EconomyServiceTests` (5 tests)
   - `OrderServiceTests` (2 tests)
   - `RenovationServiceTests` (3 tests)
   - `SaveServiceTests` (3 tests)
4. Verify all tests pass with green checkmarks.

---

## 4. Building the Android APK

### Android Player Settings:
1. Open **File** > **Build Settings**.
2. Switch platform to **Android**.
3. Click **Player Settings...** and verify:
   - **Company Name:** `HomeMergeStudios`
   - **Product Name:** `Home Merge: Dream House Designer`
   - **Default Orientation:** `Portrait`
   - **Allowed Orientations:** Portrait only (disable Auto Rotation and Landscape)
   - **Minimum API Level:** Android 7.0 'Nougat' (API Level 24)
   - **Target API Level:** Automatic (highest installed, e.g. API Level 34)
   - **Scripting Backend:** IL2CPP (or Mono for fast dev builds)
   - **Target Architectures:** ARMv7 and ARM64
4. In **Build Settings**, add `Assets/_Game/Scenes/MainGame.unity` to the **Scenes In Build** list.
5. Click **Build** (or **Build and Run** with a connected Android device with USB Debugging enabled).
6. Specify output file destination (e.g., `Builds/HomeMerge_v1.0.0.apk`).

---

## 5. Replacing Placeholder Assets

### Sprites & Art:
- Item icon sprites: Place 256×256 PNGs in `Assets/_Game/Art/Items/` (e.g. `wood_01.png` to `wood_08.png`).
- Assign sprites to `ItemDefinition` assets in `Assets/_Game/Data/Items/`.
- Room state backgrounds and décor overlays: Place in `Assets/_Game/Art/Rooms/LivingRoom/`.

### Audio:
- Place 16-bit 44.1kHz WAV/MP3 files into `Assets/_Game/Art/Audio/`.
- Assign clips to the `AudioService` inspector fields (`tapClip`, `mergeClip`, `orderCompleteClip`, `renovateClip`, `bgmMusicClip`).
