using System.Collections.Generic;
using HomeMerge.Board;
using HomeMerge.Economy;
using HomeMerge.Generators;
using HomeMerge.Items;
using HomeMerge.Orders;
using HomeMerge.Progression;
using HomeMerge.Renovation;
using HomeMerge.Save;
using UnityEngine;

namespace HomeMerge.Core
{
    public class GameBootstrap : MonoBehaviour
    {
        public static GameBootstrap Instance { get; private set; }

        [Header("Service References")]
        [SerializeField] private ItemCatalog itemCatalog;
        [SerializeField] private BoardController boardController;
        [SerializeField] private GeneratorService generatorService;
        [SerializeField] private EconomyService economyService;
        [SerializeField] private ProgressionService progressionService;
        [SerializeField] private OrderService orderService;
        [SerializeField] private RenovationService renovationService;
        [SerializeField] private SaveService saveService;
        [SerializeField] private AudioService audioService;

        public bool IsInitialized { get; private set; } = false;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);

            EnsureServices();
        }

        private void Start()
        {
            InitializeGame();
        }

        private void EnsureServices()
        {
            if (itemCatalog == null) itemCatalog = FindObjectOfType<ItemCatalog>() ?? gameObject.AddComponent<ItemCatalog>();
            if (boardController == null) boardController = FindObjectOfType<BoardController>() ?? gameObject.AddComponent<BoardController>();
            if (generatorService == null) generatorService = FindObjectOfType<GeneratorService>() ?? gameObject.AddComponent<GeneratorService>();
            if (economyService == null) economyService = FindObjectOfType<EconomyService>() ?? gameObject.AddComponent<EconomyService>();
            if (progressionService == null) progressionService = FindObjectOfType<ProgressionService>() ?? gameObject.AddComponent<ProgressionService>();
            if (orderService == null) orderService = FindObjectOfType<OrderService>() ?? gameObject.AddComponent<OrderService>();
            if (renovationService == null) renovationService = FindObjectOfType<RenovationService>() ?? gameObject.AddComponent<RenovationService>();
            if (saveService == null) saveService = FindObjectOfType<SaveService>() ?? gameObject.AddComponent<SaveService>();
            if (audioService == null) audioService = FindObjectOfType<AudioService>() ?? gameObject.AddComponent<AudioService>();
        }

        public void InitializeGame()
        {
            itemCatalog.InitializeCatalog();

            // Load saved state
            var state = saveService.Load();

            // Initialize Economy & Progression
            economyService.Initialize(state.coins, state.stars, state.gems);
            progressionService.Initialize(state.playerLevel, state.playerXP);

            // Initialize Generator & Board
            generatorService.LoadCharges(state.generatorCharges, state.energyEnabled);
            boardController.Initialize(state.boardItems);

            // Initialize Orders
            orderService.LoadOrders(state.activeOrders, state.completedOrderIds);

            // Initialize Renovation
            var styles = new Dictionary<string, string>();
            if (state.styleSelections != null)
            {
                foreach (var entry in state.styleSelections) styles[entry.taskId] = entry.styleId;
            }
            renovationService.LoadRenovationState(state.completedTaskIds, styles);

            // Initialize Audio
            if (state.settings != null)
            {
                audioService.InitializeSettings(!state.settings.sfxEnabled, !state.settings.musicEnabled, state.settings.sfxVolume, state.settings.musicVolume);
            }

            // Bind auto-save to game events
            boardController.OnBoardStateChanged += TriggerSave;
            orderService.OnOrderCompleted += (o) => { audioService.PlayOrderComplete(); TriggerSave(); };
            renovationService.OnTaskCompleted += (t) => { audioService.PlayRenovate(); TriggerSave(); };
            renovationService.OnStyleSelected += (id, style) => TriggerSave();
            boardController.OnMergeCompleted += (res) => { if (res.Success) audioService.PlayMerge(); };

            IsInitialized = true;
            Debug.Log("[GameBootstrap] Home Merge initialized successfully in offline single-player mode.");
        }

        public void TriggerSave()
        {
            if (!IsInitialized) return;

            var state = new GameStateData
            {
                playerLevel = progressionService.CurrentLevel,
                playerXP = progressionService.CurrentXP,
                coins = economyService.Coins,
                stars = economyService.Stars,
                gems = economyService.Gems,
                boardItems = boardController.Grid.GetAllItems(),
                generatorCharges = generatorService.GetCurrentCharges(),
                energyEnabled = generatorService.IsEnergyEnabled(),
                activeOrders = new List<OrderData>(orderService.ActiveOrders),
                completedOrderIds = new List<string>(orderService.CompletedOrderIds),
                currentRoomId = renovationService.CurrentRoom.roomId,
                completedTaskIds = new List<string>(renovationService.CompletedTaskIds),
                styleSelections = new List<StyleEntry>(),
                settings = new SettingsData
                {
                    sfxEnabled = !audioService.IsSfxMuted,
                    musicEnabled = !audioService.IsMusicMuted,
                    sfxVolume = audioService.SfxVolume,
                    musicVolume = audioService.MusicVolume
                }
            };

            foreach (var kvp in renovationService.TaskStyles)
            {
                state.styleSelections.Add(new StyleEntry { taskId = kvp.Key, styleId = kvp.Value });
            }

            saveService.Save(state);
        }

        private void OnApplicationPause(bool pauseStatus)
        {
            if (pauseStatus) TriggerSave();
        }

        private void OnApplicationQuit()
        {
            TriggerSave();
        }
    }
}
