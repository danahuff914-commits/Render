using System;

namespace HomeMerge.Items
{
    [Serializable]
    public class ItemInstance
    {
        public string instanceId;
        public string definitionId;
        public int gridX;
        public int gridY;

        public ItemInstance()
        {
            instanceId = Guid.NewGuid().ToString("N");
        }

        public ItemInstance(string defId, int x, int y)
        {
            instanceId = Guid.NewGuid().ToString("N");
            definitionId = defId;
            gridX = x;
            gridY = y;
        }

        public ItemInstance Clone()
        {
            return new ItemInstance
            {
                instanceId = this.instanceId,
                definitionId = this.definitionId,
                gridX = this.gridX,
                gridY = this.gridY
            };
        }
    }
}
