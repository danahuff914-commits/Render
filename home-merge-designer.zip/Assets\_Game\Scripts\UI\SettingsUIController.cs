using HomeMerge.Core;
using HomeMerge.Save;
using UnityEngine;
using UnityEngine.UI;

namespace HomeMerge.UI
{
    public class SettingsUIController : MonoBehaviour
    {
        [Header("Toggles")]
        [SerializeField] private Toggle sfxToggle;
        [SerializeField] private Toggle musicToggle;
        [SerializeField] private Toggle reducedMotionToggle;

        [Header("Reset Save & Confirmation")]
        [SerializeField] private Button resetSaveButton;
        [SerializeField] private GameObject confirmResetDialog;
        [SerializeField] private Button confirmYesButton;
        [SerializeField] private Button confirmNoButton;

        [Header("Version Display")]
        [SerializeField] private Text versionText;

        private void Start()
        {
            if (versionText != null)
            {
                versionText.text = "Home Merge MVP v1.0.0 • Offline Single-Player";
            }

            if (confirmResetDialog != null) confirmResetDialog.SetActive(false);

            BindEvents();
            SyncUI();
        }

        private void BindEvents()
        {
            if (sfxToggle != null)
            {
                sfxToggle.onValueChanged.AddListener((isOn) =>
                {
                    if (AudioService.Instance != null) AudioService.Instance.SetSfxMuted(!isOn);
                });
            }

            if (musicToggle != null)
            {
                musicToggle.onValueChanged.AddListener((isOn) =>
                {
                    if (AudioService.Instance != null) AudioService.Instance.SetMusicMuted(!isOn);
                });
            }

            if (resetSaveButton != null)
            {
                resetSaveButton.onClick.AddListener(() =>
                {
                    if (confirmResetDialog != null) confirmResetDialog.SetActive(true);
                });
            }

            if (confirmYesButton != null)
            {
                confirmYesButton.onClick.AddListener(() =>
                {
                    if (SaveService.Instance != null) SaveService.Instance.ResetSaveData();
                    if (confirmResetDialog != null) confirmResetDialog.SetActive(false);
                    if (MainUIController.Instance != null) MainUIController.Instance.OpenSettings(false);
                    // Reload scene or re-init
                    if (GameBootstrap.Instance != null) GameBootstrap.Instance.InitializeGame();
                });
            }

            if (confirmNoButton != null)
            {
                confirmNoButton.onClick.AddListener(() =>
                {
                    if (confirmResetDialog != null) confirmResetDialog.SetActive(false);
                });
            }
        }

        private void SyncUI()
        {
            if (AudioService.Instance != null)
            {
                if (sfxToggle != null) sfxToggle.isOn = !AudioService.Instance.IsSfxMuted;
                if (musicToggle != null) musicToggle.isOn = !AudioService.Instance.IsMusicMuted;
            }
        }
    }
}
